import json

class Coursework:
    COURSEWORK_TYPES = []
    get_db = ""
    query_db = ""
    action_query = ""
    check_token = ""
    redirect = ""
    url_for = ""
    render_template = ""

    def __init__(self, flask_func):
        self.get_db = flask_func[0]
        self.query_db = flask_func[1]
        self.action_query = flask_func[2]
        self.check_token = flask_func[3]
        self.redirect = flask_func[4]
        self.url_for = flask_func[5]
        self.render_template = flask_func[6]
        self.COURSEWORK_TYPES = flask_func[7]

    def show_edit_coursework_page(self, request, aid):
        auth_token = ""
        try:
            auth_token = request.cookies.get('authToken')
        except:
            return self.redirect(self.url_for('show_login'))
        tok = self.check_token(str(auth_token))
        if tok is False or tok["permissions"]["admin"]["can_manage_coursework"] == False:
            return self.redirect(self.url_for('show_login'))

        coursework_query = self.query_db(
            "SELECT aname, type, link, desc FROM coursework WHERE id=?", (aid,), True)
        if coursework_query == None:
            return self.redirect(self.url_for('manage_coursework'))

        return self.render_template("instructor/edit_coursework.html", title="Manage coursework", desc="CSCB63: Manage coursework",
                            aid=aid, aname=coursework_query[0], cw_type=coursework_query[1], link=coursework_query[2],
                            coursework_types=self.COURSEWORK_TYPES, cw_desc=coursework_query[3], identity=tok["identity"], permissions=tok["permissions"])

    def get_coursework(self):
        coursework_query = self.query_db('SELECT * FROM coursework', (), False)
        coursework = []
        for record in coursework_query:
            coursework.append({
                "name": record[2],
                "type": self.COURSEWORK_TYPES[record[1]],
                "desc": record[3],
                "link": record[4]
            })
        return coursework

    def show_coursework(self, request):
        auth_token = ""
        try:
            auth_token = request.cookies.get('authToken')
        except:
            return self.redirect(self.url_for('show_login'))
        tok = self.check_token(str(auth_token))
        if tok is False or tok["permissions"]["user"]["can_see_coursework"] == False:
            return self.redirect(self.url_for('show_login'))

        return self.render_template("student/coursework.html", title="Coursework", desc="CSCB63: Coursework", coursework=self.get_coursework(), identity=tok["identity"], permissions=tok["permissions"])

    def manage_coursework(self, request):
        auth_token = ""
        try:
            auth_token = request.cookies.get('authToken')
        except:
            return self.redirect(self.url_for('show_login'))
        tok = self.check_token(str(auth_token))
        if tok is False or tok["permissions"]["admin"]["can_manage_coursework"] == False:
            return self.redirect(self.url_for('show_login'))

        coursework = []
        coursework_query = self.query_db("SELECT * FROM coursework", (), False)

        for i in range(len(coursework_query)):
            coursework.append({
                "id": coursework_query[i][0],
                "type": coursework_query[i][1],
                "name": coursework_query[i][2],
                "desc": coursework_query[i][3],
                "link": coursework_query[i][4],
            })

        return self.render_template("instructor/coursework.html", title="Manage coursework", desc="CSCB63: Manage coursework", coursework=coursework, identity=tok["identity"], permissions=tok["permissions"])

    def save_coursework_changes(self, request):
        auth_token = ""
        try:
            auth_token = request.cookies.get('authToken')
        except:
            return json.dumps({
                "status": "error",
                "msg": "Permission denied. Either you are not authenticated, or you do not have permission to use this endpoint."
            }, indent=4)
        tok = self.check_token(str(auth_token))
        if tok is False or tok["permissions"]["admin"]["can_manage_coursework"] == False:
            return json.dumps({
                "status": "error",
                "msg": "Permission denied. Either you are not authenticated, or you do not have permission to use this endpoint."
            }, indent=4)

        aid = ""
        name = ""
        link = ""
        cw_type = ""
        desc = ""
        try:
            name = request.form['name']
            link = request.form['link']
            cw_type = request.form['cw_type']
            aid = request.form['aid']
            desc = request.form['desc']
        except:
            return json.dumps({
                "status": "error",
                "msg": "Missing one or more fields."
            }, indent=4)
        if len(name) == 0 or len(cw_type) == 0 or int(cw_type) not in range(0, len(self.COURSEWORK_TYPES)):
            return json.dumps({
                "status": "error",
                "msg": "All coursework must be assigned a name and a valid type."
            }, indent=4)
        if self.query_db("SELECT * FROM coursework WHERE id=?", (aid,), True) is None:
            return json.dumps({
                "status": "error",
                "msg": "The coursework ID (" + str(aid) + ") was not found in the system."
            }, indent=4)

        self.action_query('UPDATE coursework SET aname=?, link=?, type=?, desc=? WHERE id=?',
                    (name, link, cw_type, desc, aid))
        return json.dumps({
            "status": "success",
            "msg": "Coursework with ID (" + str(aid) + ") has been updated."
        }, indent=4)

    def delete_coursework(self, request):
        auth_token = ""
        try:
            auth_token = request.cookies.get('authToken')
        except:
            return json.dumps({
                "status": "error",
                "msg": "Permission denied. Either you are not authenticated, or you do not have permission to use this endpoint."
            }, indent=4)
        tok = self.check_token(str(auth_token))
        if tok is False or tok["permissions"]["admin"]["can_manage_coursework"] == False:
            return json.dumps({
                "status": "error",
                "msg": "Permission denied. Either you are not authenticated, or you do not have permission to use this endpoint."
            }, indent=4)

        aid = ""
        try:
            aid = request.form['aid']
        except:
            return json.dumps({
                "status": "error",
                "msg": "Missing assignment ID."
            }, indent=4)
        if self.query_db("SELECT * FROM coursework WHERE id=?", (aid,), True) is None:
            return json.dumps({
                "status": "error",
                "msg": "The coursework ID (" + str(aid) + ") was not found in the system."
            }, indent=4)
        if not self.query_db('SELECT grade_id FROM marks WHERE aid=?', (aid,), False):
            self.action_query('DELETE FROM coursework WHERE id=?', (aid,))
            return json.dumps({
                "status": "success",
                "msg": "Coursework with ID (" + str(aid) + ") has been removed."
            }, indent=4)
        else:
            return json.dumps({
                "status": "error",
                "msg": "There are grades that exist for coursework (#" + str(aid) + "). Deleting this coursework is not permitted."
            }, indent=4)

    def save_new_coursework(self, request):
        auth_token = ""
        try:
            auth_token = request.cookies.get('authToken')
        except:
            return json.dumps({
                "status": "error",
                "msg": "Permission denied. Either you are not authenticated, or you do not have permission to use this endpoint."
            }, indent=4)
        tok = self.check_token(str(auth_token))
        if tok is False or tok["permissions"]["admin"]["can_manage_coursework"] == False:
            return json.dumps({
                "status": "error",
                "msg": "Permission denied. Either you are not authenticated, or you do not have permission to use this endpoint."
            }, indent=4)

        name = ""
        link = ""
        cw_type = ""
        desc = ""
        try:
            name = request.form['name']
            link = request.form['link']
            cw_type = request.form['cw_type']
            desc = request.form['desc']
        except:
            return json.dumps({
                "status": "error",
                "msg": "Missing one or more fields."
            }, indent=4)
        if len(name) == 0 or len(cw_type) == 0 or int(cw_type) not in range(0, len(self.COURSEWORK_TYPES)):
            return json.dumps({
                "status": "error",
                "msg": "All coursework must be assigned a name and a valid type."
            }, indent=4)

        self.action_query('INSERT INTO coursework (aname, link, type, desc) VALUES (?, ?, ?, ?)',
                    (name, link, cw_type, desc))
        return json.dumps({
            "status": "success",
            "msg": "Your coursework has been successfully added."
        }, indent=4)

    def show_add_coursework_page(self, request):
        auth_token = ""
        try:
            auth_token = request.cookies.get('authToken')
        except:
            return self.redirect(self.url_for('show_login'))
        tok = self.check_token(str(auth_token))
        if tok is False or tok["permissions"]["admin"]["can_manage_coursework"] == False:
            return self.redirect(self.url_for('show_login'))

        return self.render_template("instructor/add_coursework.html", coursework_types=self.COURSEWORK_TYPES, title="Add coursework", desc="CSCB63: Add coursework", identity=tok["identity"], permissions=tok["permissions"])
