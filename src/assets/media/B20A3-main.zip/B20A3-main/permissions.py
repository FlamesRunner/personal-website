import json

class Permissions:
    get_db = ""
    query_db = ""
    action_query = ""
    check_token = ""
    redirect = ""
    url_for = ""
    render_template = ""

    def __init__(self, flask_func):
        self.get_db = flask_func[0]
        self.query_db = flask_func[1]
        self.action_query = flask_func[2]
        self.check_token = flask_func[3]
        self.redirect = flask_func[4]
        self.url_for = flask_func[5]
        self.render_template = flask_func[6]

    def manage_permissions_page(self, request):
        auth_token = ""
        try:
            auth_token = request.cookies.get('authToken')
        except:
            return self.redirect(self.url_for('show_login'))
        tok = self.check_token(str(auth_token))
        if tok is False or tok["permissions"]["admin"]["can_modify_permissions"] == False:
            return self.redirect(self.url_for('show_login'))

        permissions_query = self.query_db(
            "SELECT perm_level as id, name FROM permissions", (), False)
        if permissions_query == None:
            return self.redirect(self.url_for('manage_coursework'))
        
        roles = []
        for record in permissions_query:
            roles.append({
                "id": record[0],
                "name": record[1]
            })

        return self.render_template("superuser/permissions.html", title="Manage permissions", desc="CSCB63: Manage permissions", 
            roles=roles, identity=tok["identity"], permissions=tok["permissions"])

    def edit_role_page(self, request, roleid):
        auth_token = ""
        try:
            auth_token = request.cookies.get('authToken')
        except:
            return self.redirect(self.url_for('show_login'))
        tok = self.check_token(str(auth_token))
        if tok is False or tok["permissions"]["admin"]["can_modify_permissions"] == False:
            return self.redirect(self.url_for('show_login'))

        permissions_query = self.query_db(
            "SELECT perm_level as id, name, permissions FROM permissions WHERE id=?", (roleid,), True)
        if permissions_query == None:
            return self.redirect(self.url_for('manage_permissions_page'))

        return self.render_template("superuser/edit_permissions.html", title="Manage permissions", desc="CSCB63: Manage permissions", 
            rname=permissions_query[1], rid=permissions_query[0], rperms=json.loads(permissions_query[2]), identity=tok["identity"], permissions=tok["permissions"])

    def save_role(self, request):
        auth_token = ""
        rid = ""
        rname = ""

        try:
            auth_token = request.cookies.get('authToken')
        except:
            return json.dumps({
                "status": "error",
                "msg": "Permission denied. Either you are not authenticated, or you do not have permission to use this endpoint."
            }, indent=4)
        tok = self.check_token(str(auth_token))
        if tok is False or tok["permissions"]["admin"]["can_manage_coursework"] == False:
            return json.dumps({
                "status": "error",
                "msg": "Permission denied. Either you are not authenticated, or you do not have permission to use this endpoint."
            }, indent=4)
        try:
            rid = request.form.get('rid')
            rname = request.form.get('rname')
        except:
            return json.dumps({
                "status": "error",
                "msg": "The role ID and name are required."
            }, indent=4)
        if len(rname) == 0 or rid.isnumeric() is not True:
            return json.dumps({
                "status": "error",
                "msg": "The name cannot be empty and the role ID must be numeric."
            }, indent=4)

        permissions_query = self.query_db(
            "SELECT perm_level as id, name, permissions FROM permissions WHERE perm_level=?", (rid,), True)
        if permissions_query is None:
            return json.dumps({
                "status": "error",
                "msg": "The role ID specified not valid."
            }, indent=4)

        new_permissions = {}
        new_permissions["admin"] = {
            "can_manage_coursework": request.form.get("can_manage_coursework", default=False) == "on",
            "can_read_feedback": request.form.get("can_read_feedback", default=False) == "on",
            "can_modify_grades": request.form.get("can_modify_grades", default=False) == "on",
            "can_see_remark_request": request.form.get("can_see_remark_request", default=False) == "on",
            "can_modify_permissions": request.form.get("can_modify_permissions", default=False) == "on"
        }
        new_permissions["user"] = {
            "can_see_coursework": request.form.get("can_see_coursework", default=False) == "on",
            "can_write_feedback": request.form.get("can_write_feedback", default=False) == "on",
            "can_write_remark_request": request.form.get("can_write_remark_request", default=False) == "on",
            "can_view_own_grades": request.form.get("can_view_own_grades", default=False) == "on"
        }

        permissions_json = json.dumps(new_permissions, indent=4)
        self.action_query('UPDATE permissions SET name=?, permissions=? WHERE perm_level=?', (rname, permissions_json, rid))

        return json.dumps({
            "status": "success",
            "msg": "The role has been saved successfully."
        }, indent=4)

    def add_role_page(self, request):
        auth_token = ""
        try:
            auth_token = request.cookies.get('authToken')
        except:
            return self.redirect(self.url_for('show_login'))
        tok = self.check_token(str(auth_token))
        if tok is False or tok["permissions"]["admin"]["can_modify_permissions"] == False:
            return self.redirect(self.url_for('show_login'))

        return self.render_template("superuser/add_role.html", title="Add role", desc="CSCB63: Add role", identity=tok["identity"], permissions=tok["permissions"])

    def add_role(self, request):
        auth_token = ""
        rid = ""

        try:
            auth_token = request.cookies.get('authToken')
        except:
            return json.dumps({
                "status": "error",
                "msg": "Permission denied. Either you are not authenticated, or you do not have permission to use this endpoint."
            }, indent=4)
        tok = self.check_token(str(auth_token))
        if tok is False or tok["permissions"]["admin"]["can_manage_coursework"] == False:
            return json.dumps({
                "status": "error",
                "msg": "Permission denied. Either you are not authenticated, or you do not have permission to use this endpoint."
            }, indent=4)
        try:
            rid = request.form.get('rid')
            rname = request.form.get('rname')
        except:
            return json.dumps({
                "status": "error",
                "msg": "The role ID and name are required."
            }, indent=4)
        if len(rname) == 0 or rid.isnumeric() is not True:
            return json.dumps({
                "status": "error",
                "msg": "The name cannot be empty and the role ID must be numeric."
            }, indent=4)

        permissions_query = self.query_db(
            "SELECT perm_level as id, name, permissions FROM permissions WHERE id=?", (rid,), True)
        if permissions_query is not None:
            return json.dumps({
                "status": "error",
                "msg": "The role ID specified is already in use. Please try another."
            }, indent=4)

        self.action_query('INSERT INTO permissions (name, perm_level) VALUES (?, ?)', (rname, rid))

        return json.dumps({
            "status": "success",
            "msg": "The role has been added successfully. Please click <a href='" + self.url_for('edit_role_page', roleid=rid) + "'>here</a> to modify the permissions for this role."
        }, indent=4)

    def delete_role(self, request):
        auth_token = ""
        try:
            auth_token = request.cookies.get('authToken')
        except:
            return json.dumps({
                "status": "error",
                "msg": "Permission denied. Either you are not authenticated, or you do not have permission to use this endpoint."
            }, indent=4)
        tok = self.check_token(str(auth_token))
        if tok is False or tok["permissions"]["admin"]["can_manage_coursework"] == False:
            return json.dumps({
                "status": "error",
                "msg": "Permission denied. Either you are not authenticated, or you do not have permission to use this endpoint."
            }, indent=4)

        rid = ""
        try:
            rid = request.form['rid']
        except:
            return json.dumps({
                "status": "error",
                "msg": "Missing role ID."
            }, indent=4)
        if self.query_db("SELECT * FROM permissions WHERE perm_level=?", (rid,), True) is None:
            return json.dumps({
                "status": "error",
                "msg": "The role ID (" + str(rid) + ") was not found in the system."
            }, indent=4)
        if not self.query_db('SELECT identity FROM users WHERE perm_level=?', (rid,), False):
            self.action_query('DELETE FROM permissions WHERE perm_level=?', (rid,))
            return json.dumps({
                "status": "success",
                "msg": "Role with ID (" + str(rid) + ") has been removed."
            }, indent=4)
        else:
            return json.dumps({
                "status": "error",
                "msg": "There are users with this role (#" + str(rid) + "). Deleting this role is not permitted."
            }, indent=4)