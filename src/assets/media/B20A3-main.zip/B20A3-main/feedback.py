import json
import time
from datetime import datetime
class Feedback:
    get_db = ""
    query_db = ""
    action_query = ""
    check_token = ""
    redirect = ""
    url_for = ""
    render_template = ""

    def __init__(self, flask_func):
        self.get_db = flask_func[0]
        self.query_db = flask_func[1]
        self.action_query = flask_func[2]
        self.check_token = flask_func[3]
        self.redirect = flask_func[4]
        self.url_for = flask_func[5]
        self.render_template = flask_func[6]

    def send_feedback(self, request):
        auth_token = ""
        try:
            auth_token = request.cookies.get('authToken')
        except:
            return json.dumps({
                "status": "error",
                "msg": "No authentication token supplied."
            }, indent=4)
        tok = self.check_token(str(auth_token))
        if tok is False or tok["permissions"]["user"]["can_write_feedback"] == False:
            return json.dumps({
                "status": "error",
                "msg": "Permission denied. Either you are not authenticated, or you do not have permission to use this endpoint."
            }, indent=4)

        message = ""
        send_student_info = False
        instructor_id = ""
        try:
            message = request.form['message']
            instructor_id = request.form['instructor_id']
            send_student_info = request.form['send_student_info']
        except:
            if message is None or instructor_id is None:
                return json.dumps({
                    "status": "error",
                    "msg": "One or more fields were empty."
                }, indent=4)
        if len(message) == 0:
            return json.dumps({
                "status": "error",
                "msg": "No message was supplied."
            }, indent=4)
        if self.query_db("SELECT identity FROM users WHERE identity=? AND perm_level < 1000", (instructor_id,), True) == None:
            return json.dumps({
                "status": "error",
                "msg": "You selected an invalid instructor."
            }, indent=4)
        if send_student_info == "true":
            self.action_query("INSERT INTO `feedback` ('timestamp', 'message', 'student_number', 'to') VALUES (?, ?, ?, ?)", (int(
                time.time()), message, tok["identity"], instructor_id))
        else:
            self.action_query("INSERT INTO `feedback` ('timestamp', 'message', 'to') VALUES (?, ?, ?)", (int(
                time.time()), message, instructor_id))
        return json.dumps({
            "status": "success",
            "msg": "Message sent. You will be sent back to the dashboard in a few moments."
        }, indent=4)

    # Feedback form

    def show_feedback_form(self, request):
        auth_token = ""
        try:
            auth_token = request.cookies.get('authToken')
        except:
            return self.redirect(self.url_for('show_login'))
        tok = self.check_token(str(auth_token))
        if tok is False or tok["permissions"]["user"]["can_write_feedback"] == False:
            return self.redirect(self.url_for('show_login'))
        instructor_id_query = self.query_db(
            'SELECT identity, users.name FROM users WHERE perm_level > 0 AND perm_level < 1000', (), False)
        instructor_ids = []
        for i in range(0, len(instructor_id_query)):
            instructor_ids.append({
                "id": instructor_id_query[i][0],
                "name": instructor_id_query[i][1]
            })
        return self.render_template("student/feedback.html", title="Anonymous feedback", desc="CSCB63: Anonymous feedback", identity=tok["identity"], permissions=tok["permissions"], instructor_ids=instructor_ids)

    def mark_as_read(self, request):
        auth_token = ""
        feedback_id = ""
        try:
            auth_token = request.cookies.get('authToken')
            feedback_id = request.form['feedback_id']
        except:
            if auth_token == None:
                msg = "Permission denied. Either you are not authenticated, or you do not have permission to use this endpoint."
            else:
                msg = "Feedback ID was not specified."
            return json.dumps({
                "status": "error",
                "msg": msg
            }, indent=4)
        tok = self.check_token(str(auth_token))
        if tok is False or tok["permissions"]["admin"]["can_read_feedback"] == False:
            return json.dumps({
                "status": "error",
                "msg": "Permission denied. Either you are not authenticated, or you do not have permission to use this endpoint."
            }, indent=4)
        self.action_query('UPDATE feedback SET read=1 WHERE id=?', (feedback_id,))
        return json.dumps({
            "status": "success",
            "msg": "Feedback with ID " + str(feedback_id) + " was marked as read."
        })

    def read_feedback(self, request, show_read):
        auth_token = ""
        try:
            auth_token = request.cookies.get('authToken')
        except:
            return self.redirect(self.url_for('show_login'))
        tok = self.check_token(str(auth_token))
        if tok is False or tok["permissions"]["admin"]["can_read_feedback"] == False:
            return self.redirect(self.url_for('show_login'))

        feedback = []
        feedback_query = None
        if show_read is False:
            feedback_query = self.query_db(
                "SELECT * FROM feedback INNER JOIN users ON users.identity = feedback.`to` WHERE read=0", (), False)
        elif show_read == "all":
            feedback_query = self.query_db(
                "SELECT * FROM feedback INNER JOIN users ON users.identity = feedback.`to`", (), False)

        for i in range(len(feedback_query)):
            feedback.append({
                "id": feedback_query[i][0],
                "when": datetime.utcfromtimestamp(int(feedback_query[i][1])).strftime('%Y-%m-%d %H:%M:%S'),
                "message": feedback_query[i][2],
                "student_number": feedback_query[i][3],
                "to": feedback_query[i][8],
                "read": feedback_query[i][5]
            })

        return self.render_template("instructor/feedback.html", title="View feedback", desc="CSCB63: View feedback", feedback=feedback, identity=tok["identity"], permissions=tok["permissions"])
