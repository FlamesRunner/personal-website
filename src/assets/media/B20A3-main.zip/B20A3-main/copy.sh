#!/bin/bash
cp /mnt/c/Users/Andrew/Desktop/b20a3.db fresh.db
