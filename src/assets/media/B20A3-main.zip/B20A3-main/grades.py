import json
import time
from datetime import datetime
class Grades:
    get_db = ""
    query_db = ""
    action_query = ""
    check_token = ""
    redirect = ""
    url_for = ""
    render_template = ""
    fetch_marks = ""
    fetch_all_marks = ""
    COURSEWORK_TYPES = ""

    def __init__(self, flask_func):
        self.get_db = flask_func[0]
        self.query_db = flask_func[1]
        self.action_query = flask_func[2]
        self.check_token = flask_func[3]
        self.redirect = flask_func[4]
        self.url_for = flask_func[5]
        self.render_template = flask_func[6]
        self.fetch_marks = flask_func[7]
        self.fetch_all_marks = flask_func[8]
        self.COURSEWORK_TYPES = flask_func[9]

    def show_my_grades(self, request):
        auth_token = ""
        try:
            auth_token = request.cookies.get('authToken')
        except:
            return self.redirect(self.url_for('show_login'))
        tok = self.check_token(str(auth_token))
        if tok is False or tok["permissions"]["user"]["can_view_own_grades"] == False:
            return self.redirect(self.url_for('show_login'))
        grades = self.fetch_marks(tok["identity"])
        total = 0
        num = 0
        for mk in grades:
            if mk is False or mk["grade"] == "":
                continue
            else:
                num = num + 1
                total += mk["grade"]
        return self.render_template("student/grades.html", title="My grades", desc="CSCB63: My grades", avg=((round((total * 10) / num) 
            if num > 0 else 0) / 10), marks=grades, identity=tok["identity"], permissions=tok["permissions"])

    def manage_grades(self, request):
        auth_token = ""
        try:
            auth_token = request.cookies.get('authToken')
        except:
            return self.redirect(self.url_for('show_login'))
        tok = self.check_token(str(auth_token))
        if tok is False or tok["permissions"]["admin"]["can_modify_grades"] == False:
            return self.redirect(self.url_for('show_login'))

        return self.render_template("instructor/grades.html", coursework_types=self.COURSEWORK_TYPES, title="Grade management", desc="CSCB63: Grade management", marks=self.fetch_all_marks(), identity=tok["identity"], permissions=tok["permissions"])

    def save_mark_changes(self, request):
        auth_token = ""
        try:
            auth_token = request.cookies.get('authToken')
        except:
            return json.dumps({
                "status": "error",
                "msg": "Permission denied. Either you are not authenticated, or you do not have permission to use this endpoint."
            }, indent=4)
        tok = self.check_token(str(auth_token))
        if tok is False or tok["permissions"]["admin"]["can_manage_coursework"] == False:
            return json.dumps({
                "status": "error",
                "msg": "Permission denied. Either you are not authenticated, or you do not have permission to use this endpoint."
            }, indent=4)

        assignment_id = ""
        identity = ""
        mark = ""
        try:
            assignment_id = request.form['assignment_id']
            identity = request.form['identity']
            mark = request.form['mark']
        except:
            return json.dumps({
                "status": "error",
                "msg": "Missing one or more fields."
            }, indent=4)
        if mark != "" and (int(mark) > 100 or int(mark) < 0):
            return json.dumps({
                "status": "error",
                "msg": "Marks must be from 0 to 100, or set to nothing for it to not be counted."
            }, indent=4)
        if self.query_db('SELECT * FROM users WHERE identity=? AND perm_level > 1', (identity,), True) is None:
            return json.dumps({
                "status": "error",
                "msg": "Critical error: Student ID was not found. Please reload the page."
            }, indent=4)
        if self.query_db('SELECT * FROM coursework WHERE id=?', (assignment_id,), True) is None:
            return json.dumps({
                "status": "error",
                "msg": "Coursework not found. Please reload the page."
            }, indent=4)
        if self.query_db("SELECT * FROM marks WHERE aid=? AND student_number=?", (assignment_id, identity), True) is None:
            # Insert
            self.action_query('INSERT INTO marks (student_number, aid, grade) VALUES (?, ?, ?)', (identity, assignment_id, mark))
        else:
            if mark == "":
                self.action_query('DELETE FROM marks WHERE aid=? AND student_number=?', (assignment_id, identity))
            else:
                # Update
                self.action_query('UPDATE marks SET grade=? WHERE aid=? AND student_number=?', (mark, assignment_id, identity))

        return json.dumps({
            "status": "success",
            "msg": "Grade updated."
        }, indent=4)

    def manage_assignment_grades(self, request, aid):
        auth_token = ""
        try:
            auth_token = request.cookies.get('authToken')
        except:
            return self.redirect(self.url_for('show_login'))
        tok = self.check_token(str(auth_token))
        if tok is False or tok["permissions"]["admin"]["can_modify_grades"] == False:
            return self.redirect(self.url_for('show_login'))

        marks = self.fetch_all_marks()
        mark_dict = {}
        mark_dict[str(aid)] = {}
        aname = ""
        for student_id in marks[aid]:
            if student_id == "assignment_name":
                aname = marks[aid][student_id]
                continue
            mark_dict[str(aid)][student_id] = marks[aid][student_id]
                
        return self.render_template("instructor/grade_assignment.html", coursework_types=self.COURSEWORK_TYPES, title="Grade management", desc="CSCB63: Grade management", marks=mark_dict, aname=aname, identity=tok["identity"], permissions=tok["permissions"])
