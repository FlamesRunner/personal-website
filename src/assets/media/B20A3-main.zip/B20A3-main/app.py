import sqlite3
import json
import hashlib
import secrets
import time
from datetime import datetime
from flask import Flask, render_template, g, request, redirect, url_for, make_response
from coursework import Coursework
from feedback import Feedback
from grades import Grades
from remark import Remark
from permissions import Permissions
app = Flask(__name__)

DATABASE = './assignment3.db'
COURSEWORK_TYPES = [
    "Assignment",
    "Lab",
    "Quiz",
    "Test",
    "Exam"
]

# Get database object
def get_db():
    db = getattr(g, '_database', None)
    if db is None:
        db = g._database = sqlite3.connect(DATABASE)
    return db

# Database fetch
def query_db(query, args=(), single=False):
    cur = get_db().execute(query, args)
    rv = cur.fetchall()
    cur.close()
    return (rv[0] if rv else None) if single else rv

# Database query
def action_query(query, params):
    c = get_db().cursor()
    c.execute(query, params)
    get_db().commit()

# Delete token
def delete_token(token):
    return (action_query("DELETE FROM sessions WHERE sess_id=?", (token,)) == 1)

# Generate Flask function list
def flask_func(extra):
    lst = [get_db, query_db, action_query, check_token, redirect, url_for, render_template]
    lst = lst + extra # wtf
    return lst

# Verify authentication token and get details
def check_token(token):
    res = query_db("SELECT * FROM sessions WHERE sess_id=?", (token,), True)
    if res == None:
        return False
    elif res[2] < int(time.time()):
        # Token expired.
        delete_token(token)
        return False
    else:
        # Get user object
        user = query_db("SELECT * FROM users WHERE identity=?",
                        (res[1],), True)
        # Get permissions
        perms = query_db(
            "SELECT * FROM permissions WHERE perm_level=?", (user[1],), True)
        return {
            "identity": res[1],
            "name": user[2],
            "permissions": json.loads(perms[2]),
            "expiry": res[2]
        }

# Login route
@app.route('/login')
def show_login():
    return render_template("login.html", title="Sign in", desc="CSCB63: Sign in")

# Login API route
@app.route('/api/user/login', methods=['POST'])
def authenticate():
    email = ""
    password = ""
    try:
        email = request.form['email']
        password = request.form['password']
    except:
        return json.dumps({
            "status": "error",
            "msg": "One or more fields were empty."
        }, indent=4)
    ret = query_db("SELECT * FROM users WHERE email=? AND password=?",
                   (str(email), hashlib.sha256(password.encode('utf-8')).hexdigest()), True)
    if ret is None:
        return json.dumps({
            "status": "error",
            "msg": "Invalid email address/password."
        }, indent=4)
    else:
        # Successfully authenticated
        student_number = ret[0]
        expiry = int(time.time()) + 86400
        combo = str(student_number) + str(expiry) + secrets.token_urlsafe(16)
        token = hashlib.sha256(combo.encode('utf-8')).hexdigest()
        action_query("INSERT INTO `sessions` ('sess_id', 'authenticates', 'expiry') VALUES(?, ?, ?)",
                     (token, student_number, expiry))
        return json.dumps({
            "status": "authenticated",
            "msg": "Login successful, redirecting...",
            "expiry": expiry,
            "token": token
        }, indent=4)

# Home route
@app.route('/', methods=['GET'])
def home():
    auth_token = ""
    try:
        auth_token = request.cookies.get('authToken')
    except:
        return redirect(url_for('show_login'))
    tok = check_token(str(auth_token))
    if tok is False:
        return redirect(url_for('show_login'))
    marks = fetch_marks(tok["identity"])
    coursework = Coursework(flask_func([COURSEWORK_TYPES])).get_coursework()
    regrade_requests = 0
    feedback = 0
    if tok["permissions"]["admin"]["can_read_feedback"] == True:  # Return amount of feedback to read
        feedback_query = query_db(
            "SELECT count(*) FROM feedback WHERE read=0", (), True)
        feedback = feedback_query[0]
    total_to_grade = 0
    if tok["permissions"]["admin"]["can_modify_grades"] == True:
        all_marks_dict = fetch_all_marks()
        for assignment_id in all_marks_dict:
            for student_id in all_marks_dict[assignment_id]:
                if student_id == "assignment_name": continue
                curr_grade = all_marks_dict[assignment_id][student_id]["grade"] 
                if curr_grade == None or curr_grade == "": total_to_grade = total_to_grade + 1
    if tok["permissions"]["admin"]["can_see_remark_request"] == True:
        regrade_query = query_db(
            "SELECT COUNT(*) FROM remark_requests WHERE status=0", (), True)
        regrade_requests = regrade_query[0]
    return render_template("home.html", title="Home", desc="CSCB63: Home", regrade_requests=regrade_requests, total_to_grade=total_to_grade, feedback=feedback, 
    name=tok["name"], identity=tok["identity"], permissions=tok["permissions"], marks=marks[:2], coursework=coursework[:3])

# Registration page route
@app.route('/register', methods=['GET'])
def show_register():
    if request.cookies.get('authToken') is not None and check_token(str(request.cookies.get('authToken'))) is not False:
        return redirect(url_for('home'))
    res = query_db('SELECT perm_level, name FROM permissions', (), False)
    return render_template("register.html", title="Register", desc="CSCB63: Sign up", roles=res)

# Login API route
@app.route('/api/user/register', methods=['POST'])
def signup():
    email = ""
    password = ""
    name = ""
    student_number = ""
    role_id = ""
    try:
        email = request.form['email']
        password = request.form['password']
        student_number = request.form['student_number']
        name = request.form['name']
        role_id = request.form['role_id']
    except:
        return json.dumps({
            "status": "error",
            "msg": "One or more fields were empty."
        }, indent=4)
    if len(password) < 3:
        return json.dumps({
            "status": "error",
            "msg": "Password must be at least 3 characters."
        }, indent=4)
    ret_a = query_db("SELECT * FROM users WHERE identity=?",
                     (student_number,), True)
    ret_b = query_db(
        "SELECT * FROM permissions WHERE perm_level=?", (role_id,), True)

    if ret_a is not None:
        return json.dumps({
            "status": "error",
            "msg": "The identity number is already in use.",
        }, indent=4)
    elif ret_b is None:
        return json.dumps({
            "status": "error",
            "msg": "The user role specified is not valid.",
        })
    else:
        # Info checks out
        action_query("INSERT INTO `users` ('identity', 'perm_level', 'name', 'email', 'password') VALUES(?, ?, ?, ?, ?)",
                     (student_number, role_id, name, email, hashlib.sha256(password.encode('utf-8')).hexdigest()))
        return json.dumps({
            "status": "success",
            "msg": "Account created",
        }, indent=4)

# Signout route
@app.route('/signout', methods=['GET'])
def signout():
    auth_token = ""
    try:
        auth_token = request.cookies.get('authToken')
    except:
        return redirect(url_for('show_login'))
    tok = check_token(str(auth_token))
    resp = make_response(redirect(url_for('show_login')))
    if tok is not None:
        delete_token(auth_token)
        resp.set_cookie('authToken', '', expires=0)
    return resp

# Teardown
@app.teardown_appcontext
def close_connection(ex):
    db = getattr(g, '_database', None)
    if db is not None:
        db.close()

# Remark API route
@app.route("/api/user/submit_remark", methods=["POST"])
def submit_remark():
   rmk = Remark(flask_func([]))
   return rmk.submit_remark(request)

# Remark page
@app.route('/remark/<aid>', methods=['GET'])
def show_remark(aid):
   rmk = Remark(flask_func([]))
   return rmk.show_remark(request, aid)

# Leave feedback page
@app.route('/leave_feedback', methods=['GET'])
def send_feedback_form():
    fb = Feedback(flask_func([]))
    return fb.show_feedback_form(request)

# Fetch marks helper method
def fetch_marks(student_number):
    marks_query = query_db(
        'SELECT * FROM marks INNER JOIN coursework ON coursework.id = marks.aid WHERE student_number=?', (student_number,), False)
    marks = []
    for record in marks_query:
        marks.append({
            "name": record[6],
            "grade": record[3],
            "aid": record[2]
        })
    return marks

# Show student grades
@app.route('/mygrades', methods=['GET'])
def show_my_grades():
    gd = Grades(flask_func([fetch_marks, fetch_all_marks, COURSEWORK_TYPES]))
    return gd.show_my_grades(request)

# Send feedback API
@app.route('/api/user/send_feedback', methods=['POST'])
def send_feedback():
    fb = Feedback(flask_func([]))
    return fb.send_feedback(request)

# Read feedback page
@app.route('/feedback/read', defaults={'show_read': False})
@app.route('/feedback/read/<show_read>')
def read_feedback(show_read):
    fb = Feedback(flask_func([]))
    return fb.read_feedback(request, show_read)

# Mark feedback as read API
@app.route('/api/admin/feedback/read/', methods=['POST'])
def mark_as_read():
    fb = Feedback(flask_func([]))
    return fb.mark_as_read(request)

# Show coursework as student
@app.route('/coursework', methods=['GET'])
def show_coursework_page():
    cw = Coursework(flask_func([COURSEWORK_TYPES]))
    return cw.show_coursework(request)

# Manage coursework route
@app.route('/manage/coursework')
def manage_coursework():
    cw = Coursework(flask_func([COURSEWORK_TYPES]))
    return cw.manage_coursework(request)

# Coursework editor page
@app.route('/manage/coursework/<aid>')
def edit_coursework(aid):
    cw = Coursework(flask_func([COURSEWORK_TYPES]))
    return cw.show_edit_coursework_page(request, aid)

# Save coursework changes API
@app.route('/api/edit/coursework', methods=['POST'])
def save_coursework():
    cw = Coursework(flask_func([COURSEWORK_TYPES]))
    return cw.save_coursework_changes(request)

# Remove coursework API
@app.route('/api/remove/coursework', methods=['POST'])
def remove_coursework():
    cw = Coursework(flask_func([COURSEWORK_TYPES]))
    return cw.delete_coursework(request)

# Add coursework API
@app.route('/api/new/coursework', methods=['POST'])
def add_coursework():
    cw = Coursework(flask_func([COURSEWORK_TYPES]))
    return cw.save_new_coursework(request)

# Add coursework page
@app.route('/add/coursework')
def add_coursework_page():
    cw = Coursework(flask_func([COURSEWORK_TYPES]))
    return cw.show_add_coursework_page(request)

# Manage marks page
@app.route('/manage/grades')
def manage_grades():
    gd = Grades(flask_func([fetch_marks, fetch_all_marks, COURSEWORK_TYPES]))
    return gd.manage_grades(request)

# Fetch all marks helper method
def fetch_all_marks():
    grade_query = query_db(
        'SELECT aid, student_number, grade FROM marks INNER JOIN coursework ON marks.aid = coursework.id', (), False)
    student_coursework = query_db(
        'SELECT coursework.id as cid, identity, name, aname FROM coursework NATURAL JOIN users WHERE users.perm_level > 1;', (), False)
    all_grades = {}

    for record_id in range(0, len(student_coursework)):
        temp_key = str(student_coursework[record_id][0])
        if temp_key not in all_grades.keys():
            all_grades[temp_key] = {}
        all_grades[temp_key]["assignment_name"] = student_coursework[record_id][3]
        all_grades[temp_key][str(student_coursework[record_id][1])] = {
            "student_name": student_coursework[record_id][2],
            "assignment_name": student_coursework[record_id][3],
            "grade": None
        }

    for record_id in range(0, len(grade_query)):
        aid = grade_query[record_id][0]
        student_number = grade_query[record_id][1]
        grade = grade_query[record_id][2]
        all_grades[str(aid)][str(student_number)]["grade"] = grade
    return all_grades

# Edit grade API
@app.route('/api/edit/grade', methods=['POST'])
def save_mark_changes():
    gd = Grades(flask_func([fetch_marks, fetch_all_marks, COURSEWORK_TYPES]))
    return gd.save_mark_changes(request)

# Show all regrade requests
@app.route('/regrade_requests/read', defaults={'show_read': False})
@app.route('/regrade_requests/read/<show_read>')
def read_regrade_requests(show_read):
    rmk = Remark(flask_func([]))
    return rmk.read_remark_requests(request, show_read)

# Mark regrade as read API
@app.route('/api/admin/regrade/read', methods=['POST'])
def mark_regrade_as_read():
    rmk = Remark(flask_func([]))
    return rmk.mark_regrade_as_read(request)

# Manage assignment grades page
@app.route('/manage/grades/<aid>')
def manage_assignment_grades(aid):
    gd = Grades(flask_func([fetch_marks, fetch_all_marks, COURSEWORK_TYPES]))
    return gd.manage_assignment_grades(request, aid)

# Permissions management page
@app.route('/manage/permissions')
def manage_permissions_page():
    pm = Permissions(flask_func([]))
    return pm.manage_permissions_page(request)

# Modify role page
@app.route('/edit/role/<roleid>')
def edit_role_page(roleid):
    pm = Permissions(flask_func([]))
    return pm.edit_role_page(request, roleid)

# Save role API
@app.route('/api/admin/permissions/save', methods=['POST'])
def save_role():
    pm = Permissions(flask_func([]))
    return pm.save_role(request)

# New role
@app.route('/add/role')
def add_role_page():
    pm = Permissions(flask_func([]))
    return pm.add_role_page(request)

# New role API
@app.route('/api/admin/role/add', methods=['POST'])
def add_role():
    pm = Permissions(flask_func([]))
    return pm.add_role(request)

# Delete role API
@app.route('/api/admin/role/delete', methods=['POST'])
def delete_role():
    pm = Permissions(flask_func([]))
    return pm.delete_role(request)

# Profile URL
@app.route('/profile', methods=['GET'])
def profile_page():
    auth_token = ""
    try:
        auth_token = request.cookies.get('authToken')
    except:
        return redirect(url_for('show_login'))
    tok = check_token(str(auth_token))
    if tok is False:
        return redirect(url_for('show_login'))
    return render_template("profile.html", title="Profile", desc="CSCB63: Profile", name=tok["name"], identity=tok["identity"], permissions=tok["permissions"])

# Update profile API
@app.route('/api/user/update/profile', methods=['POST'])
def update_profile_api():
    auth_token = ""
    name = ""
    new_pass = request.form.get('password')
    try:
        auth_token = request.cookies.get('authToken')
        name = request.form['name']
    except:
        if auth_token == None:
            msg = "Permission denied. Either you are not authenticated, or you do not have permission to use this endpoint."
        else:
            msg = "One or more fields were empty."
        return json.dumps({
            "status": "error",
            "msg": msg
        }, indent=4)
    if len(name) == 0:
        return json.dumps({
            "status": "error",
            "msg": "Name cannot be empty."
        }, indent=4)
    tok = check_token(str(auth_token))
    if tok is False:
        return json.dumps({
            "status": "error",
            "msg": "Permission denied. Either you are not authenticated, or you do not have permission to use this endpoint."
        }, indent=4)
    hashed_pass = hashlib.sha256(new_pass.encode('utf-8')).hexdigest()
    if len(new_pass) > 0:
        action_query('UPDATE users SET `password`=?, `name`=? WHERE identity=?', (hashed_pass, name, tok["identity"]))
    else:
        action_query('UPDATE users SET `name`=? WHERE identity=?', (name, tok["identity"]))
    return json.dumps({
        "status": "success",
        "msg": "Profile updated. You will be redirected in a few moments."
    })
