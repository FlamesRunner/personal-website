#!/bin/bash
cp fresh.db assignment3.db
export FLASK_ENV=development
export FLASK_APP=app.py
flask run
