import json
import time
from datetime import datetime
class Remark:
    get_db = ""
    query_db = ""
    action_query = ""
    check_token = ""
    redirect = ""
    url_for = ""
    render_template = ""

    def __init__(self, flask_func):
        self.get_db = flask_func[0]
        self.query_db = flask_func[1]
        self.action_query = flask_func[2]
        self.check_token = flask_func[3]
        self.redirect = flask_func[4]
        self.url_for = flask_func[5]
        self.render_template = flask_func[6]

    def show_remark(self, request, aid):
        auth_token = ""
        try:
            auth_token = request.cookies.get('authToken')
        except:
            return self.redirect(self.url_for('show_login'))
        tok = self.check_token(str(auth_token))
        if tok is False or tok["permissions"]["user"]["can_write_remark_request"] == False:
            return self.redirect(self.url_for('show_login'))
        assignment_query = self.query_db(
            "SELECT aname FROM coursework WHERE id=?", (aid,), True)
        if assignment_query is None:
            return self.redirect(self.url_for('home'))
        aname = assignment_query[0]

        return self.render_template("student/remark.html", title="Remark request", desc="CSCB63: Remark request", aid=aid, aname=aname, identity=tok["identity"], permissions=tok["permissions"])

    def submit_remark(self, request):
        auth_token = ""
        try:
            auth_token = request.cookies.get('authToken')
        except:
            return json.dumps({
                "status": "error",
                "msg": "No authentication token supplied."
            }, indent=4)
        tok = self.check_token(str(auth_token))
        if tok is False or tok["permissions"]["user"]["can_write_remark_request"] == False:
            return json.dumps({
                "status": "error",
                "msg": "Permission denied. Either you are not authenticated, or you do not have permission to use this endpoint."
            }, indent=4)

        message = ""
        assignment_id = ""
        try:
            message = request.form['message']
            assignment_id = request.form['assignment_id']
        except:
            if message is None:
                return json.dumps({
                    "status": "error",
                    "msg": "One or more fields were empty."
                }, indent=4)
        self.action_query("INSERT INTO `remark_requests` ('student_id', 'aid', 'message', 'timestamp') VALUES (?, ?, ?, ?)",
                    (tok["identity"], assignment_id, message, int(time.time())))
        return json.dumps({
            "status": "success",
            "msg": "Regrade request sent. You will be sent back to the dashboard in a few moments."
        }, indent=4)

    def read_remark_requests(self, request, show_read):
        auth_token = ""
        try:
            auth_token = request.cookies.get('authToken')
        except:
            return self.redirect(self.url_for('show_login'))
        tok = self.check_token(str(auth_token))
        if tok is False or tok["permissions"]["admin"]["can_see_remark_request"] == False:
            return self.redirect(self.url_for('show_login'))

        regrade = []
        regrade_query = None
        if show_read is False:
            regrade_query = self.query_db(
                "SELECT * FROM remark_requests INNER JOIN users ON users.identity = student_id WHERE status=0 ", (), False)
        elif show_read == "all":
            regrade_query = self.query_db(
                "SELECT * FROM remark_requests INNER JOIN users ON users.identity = student_id", (), False)
        print(regrade_query)
        for i in range(len(regrade_query)):
            regrade.append({
                "id": regrade_query[i][0],
                "aid": regrade_query[i][2],
                "when": datetime.utcfromtimestamp(int(regrade_query[i][4])).strftime('%Y-%m-%d %H:%M:%S'),
                "message": regrade_query[i][3],
                "student_number": regrade_query[i][1],
                "status": regrade_query[i][5],
                "from": regrade_query[i][8]
            })

        return self.render_template("instructor/remarks.html", title="Regrade requests", desc="CSCB63: Regrade requests", regrade_requests=regrade, 
            identity=tok["identity"], permissions=tok["permissions"])

    def mark_regrade_as_read(self, request):
        auth_token = ""
        rid = ""
        try:
            auth_token = request.cookies.get('authToken')
            rid = request.form['rid']
        except:
            if auth_token == None:
                msg = "Permission denied. Either you are not authenticated, or you do not have permission to use this endpoint."
            else:
                msg = "Regrade request ID was not specified."
            return json.dumps({
                "status": "error",
                "msg": msg
            }, indent=4)
        tok = self.check_token(str(auth_token))
        if tok is False or tok["permissions"]["admin"]["can_see_remark_request"] == False:
            return json.dumps({
                "status": "error",
                "msg": "Permission denied. Either you are not authenticated, or you do not have permission to use this endpoint."
            }, indent=4)
        self.action_query('UPDATE remark_requests SET `status`=1 WHERE id=?', (rid,))
        return json.dumps({
            "status": "success",
            "msg": "Regrade request with ID " + str(rid) + " was marked as read."
        })
