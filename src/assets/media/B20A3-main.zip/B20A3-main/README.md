# "Build" scripts
- start.sh is used to start a development server provided you have Flask and Python 3.8 installed.
- fresh.db is a sample database with the appropriate structures and a few test records
- assignment3.db contains the working database

# Guide

Here, we discuss the usage of this software as a student, instructor and superuser.

Superusers:
- The software employs a rather granular set of permissions. As a superuser, you may actually modify what each user is capable of doing; indeed, this means that for example, a student might not be able to see what coursework is available, but would be able to see their marks, etc.
- Superusers can create new roles and modify existing roles' permissions, as well as delete unused roles.

Instructors (default permission set):
- By default, there are two instructor users:
  - Username: instructor1, password: instructor1
  - Username: instructor2, password: instructor2
- However, nothing prevents a new user from simply registering as an instructor or superuser or student (an intentional flaw introduced for ease of testing)
- Homepage:
  - On the homepage, instructors will find a brief overfiew of tasks to be completed. That is, the number of assignments/labs/coursework left to grade, how many remark requests are unread and how many feedback notes are to be read. 
- On the _Grade Management_ page, instructors can see the marks for all students grouped under assignments. In addition, the system automatically saves any changes made to grades, hence the lack of a save button.
- On the _Regrade Requests_ page, instructors can view regrade requests from students, as well as mark them as read once they have been processed. Regrade requests will always have an identifying ID to them as well as the student name.
- On the _Manage coursework_ page, instructors can add new coursework (assigments, labs, quizzes, tests, exams), as well as edit, grade and download existing coursework.
- On the _Feedback_ page, instructors can read student feedback, and if a student has chosen to transmit their student ID along with their request, it will be shown accordingly.

Students (default permission set):
- By default, there are two student users:
  - Username: student1, password: student1
  - Username: student2, password: student2
- Homepage:
  - On the homepage, students will find a brief overview of their progress through the course. That is, their most recent grades will be shown, any recent labs/assignments/tests/exams can be downloaded and a link to provide anonymous feedback provided.
  - On the _My Grades_ page, students can view marked coursework. In addition, they may also write a remark request.
  - On the _Anonymous Feedback_ page, students can provide feedback to specific instructors (a dropdown is given so that they can select the appropriate person) and, if applicable, transmit their student information so that the instructor can provide a response.

All users:
- On the _Profile_ page, users can modify their full name as well as their passwords.

# API endpoints

## Quick links

- [Superuser/administrative endpoints](#superusersadministrators)
- [Instructor endpoints](#instructors)
- [Student endpoints](#students)

### Enumerations

    COURSEWORK_TYPES = [
        "Assignment", # (Index 0)
        "Lab" # (Index 1)
    ]

### Error responses

If the API endpoint that you queried encounters an error, all endpoints will respond with the following format:

    {
        "status": "error",
        "msg": "error message"
    }

Across all authenticated endpoints, the following responses are possible:
  - "No authentication token supplied."
  - "Permission denied. Either you are not authenticated, or you do not have permission to use this endpoint."

# All users
## Endpoint: /api/user/login

Request type: POST

Parameters:
- email: string
- password: string

On success:

    {
        "status": "authenticated",
        "msg": "Login successful, redirecting...",
        "expiry": expiry,
        "token": token
    }

On error, there are several possible error messages:
- "Invalid email address/password."
- "One or more fields were empty."

## Endpoint: /api/user/register

Request type: POST

Parameters:
- email: string
- password: string
- name: string
- student_number: integer
- role_id: integer

On success:

    {
        "status": "success",
        "msg": "Account created"
    }

On error, there are several possible error messages:
  - "The user role specified is not valid."
  - "The identity number is already in use."
  - "Password must be at least 3 characters."
  - "One or more fields were empty."


# Students
## Endpoint: /api/user/submit_remark

Request type: POST

Parameters:
- message: string
- assignment_id: integer

On success:

    {
        "status": "success",
        "msg": "Regrade request sent. You will be sent back to the dashboard in a few moments."
    }

There is only one possible error message:
- "One or more fields were empty."

## Endpoint: /api/user/send_feedback

Request type: POST

Parameters:
- message: string
- send_student_info: boolean
- instructor_id: integer

On success:

    {
        "status": "success",
        "msg": "Message sent. You will be sent back to the dashboard in a few moments."
    }

On error, there are several possible error messages:
- "One or more fields were empty."
- "You selected an invalid instructor."
- "No message was supplied."

# Instructors
## Endpoint: /api/admin/feedback/read/

This endpoint marks feedback as read.

Request type: POST

Parameters:
- feedback_id: integer

On success:

    {
        "status": "success",
        "msg": "Feedback with ID {feedback_id} was marked as read."
    }

There is only one possible error message:
- "Feedback ID was not specified"

## Endpoint: /api/edit/coursework

This endpoint modifies existing coursework.

Request type: POST

Parameters:
- name: string
- link: string
- cw_type: integer
  - Abbreviated _coursework type_; either an assignment, or a lab, etc.
  - One of the values in COURSEWORK_TYPES
- aid: integer
  - Assignment ID
- desc: string

On success:

    {
        "status": "success",
        "msg": "Coursework with ID {aid} has been updated."
    }

On error, there are several possible error messages:
- "The coursework ID {aid} was not found in the system."
- "All coursework must be assigned a name and a valid type."

## Endpoint: /api/remove/coursework

This endpoint removes existing coursework.

Request type: POST

Parameters:
- aid: integer
  - Assignment ID

On success:

    {
        "status": "success",
        "msg": "Coursework with ID {aid} has been removed."
    }

On error, there are several possible error messages:
- "The coursework ID {aid} was not found in the system."
- "There are grades that exist for coursework (#{aid}). Deleting this coursework is not permitted."

## Endpoint: /api/new/coursework

This endpoint adds new coursework.

Request type: POST

Parameters:
- name: string
- link: string
- cw_type: integer
  - Abbreviated _coursework type_; either an assignment, or a lab, etc.
  - One of the values in COURSEWORK_TYPES

On success:

    {
        "status": "success",
        "msg": "Your coursework has been successfully added."
    }

There is only one possible error message:
- "All coursework must be assigned a name and a valid type."

## Endpoint: /api/edit/grade

This endpoint modifies a grade for a particular student.

Request type: POST

Parameters:
- assignment_id: integer
- identity: integer
- mark: integer

On success:

    {
        "status": "success",
        "msg": "Grade updated."
    }

On error, there are several possible error messages:
- "Coursework not found. Please reload the page."
- "Critical error: Student ID was not found. Please reload the page."
- "Marks must be from 0 to 100, or set to nothing for it to not be counted."

## Endpoint: /api/admin/regrade/read

This endpoint modifies a grade for a particular student.

Request type: POST

Parameters:
- rid: integer
- Remark request ID

On success:

    {
        "status": "success",
        "msg": "Regrade request with ID {rid} was marked as read."
    }

There is only one possible error message:
- "Regrade request ID was not specified."

# Superusers/administrators
## Endpoint: /api/admin/permissions/save

This endpoint saves permissions for a particular role.

Request type: POST

Parameters:
- rid: integer
  - Role ID
- rname: string
  - Role name

Additional parameters (set to "on" to add permission, otherwise set to "off" to remove permission):
- can_manage_coursework
- can_read_feedback
- can_modify_grades
- can_see_remark_request
- can_modify_permissions
- can_see_coursework
- can_write_feedback
- can_write_remark_request
- can_view_own_grades

On success:

    {
        "status": "success",
        "msg": "The role has been saved successfully."
    }

On error, there are several possible error messages:
- "The role ID specified not valid."
- "The name cannot be empty and the role ID must be numeric."
- "The role ID and name are required."

## Endpoint: /api/admin/role/add

This endpoint adds a new role.

Request type: POST

Parameters:
- rid: integer
  - New role ID
- rname: string
  - Role name

On success:

    {
        "status": "success",
        "msg": "The role has been added successfully [...]"
    }

On error, there are several possible error messages:
- "The role ID specified is already in use. Please try another."
- "The name cannot be empty and the role ID must be numeric."
- "The role ID and name are required."

## Endpoint: /api/admin/role/delete

This endpoint removes an unused role (the role must not be in use by at least one user)

Request type: POST

Parameters:
- rid: integer
  - Role ID to delete

On success:

    {
        "status": "success",
        "msg": "Role with ID ({rid}) has been removed."
    }

On error, there are several possible error messages:
- "Missing role ID."
- "The role ID ({rid}) was not found in the system."
- "There are users with this role (#{rid}). Deleting this role is not permitted."