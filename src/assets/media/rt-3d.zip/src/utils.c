/*
   utils.c
   Utilities for the ray tracer. See RayTracer.c for credits.
*/

#include "utils.h"

// A useful 4x4 identity matrix which can be used at any point to
// initialize or reset object transformations
double eye4x4[4][4] = {{1.0, 0.0, 0.0, 0.0},
                       {0.0, 1.0, 0.0, 0.0},
                       {0.0, 0.0, 1.0, 0.0},
                       {0.0, 0.0, 0.0, 1.0}};

/////////////////////////////////////////////
// User-defined functions
/////////////////////////////////////////////
void MatTranspose(double matrix[4][4])
{
  double temp;
  for (int i = 0; i < 3; i++)
  {
    for (int j = i + 1; j < 3; j++)
    {
      temp = matrix[i][j];
      matrix[i][j] = matrix[j][i];
      matrix[j][i] = temp;
    }
  }
}

/////////////////////////////////////////////
// Primitive data structure section
/////////////////////////////////////////////
struct point3D *newPoint(double px, double py, double pz)
{
  // Allocate a new point structure, initialize it to
  // the specified coordinates, and return a pointer
  // to it.

  struct point3D *pt = (struct point3D *)calloc(1, sizeof(struct point3D));
  if (!pt)
    fprintf(stderr, "Out of memory allocating point structure!\n");
  else
  {
    pt->px = px;
    pt->py = py;
    pt->pz = pz;
    pt->pw = 1.0;
  }
  return (pt);
}

void solveQuadratic(double A, double B, double C, double *solutions, int *solutions_c)
{
  /**
   * @brief Solves a quadratic equation, given A, B and C. Sets solutions array and solution count
   * as required.
   *
   */
  double discriminant = B * B - 4.0 * A * C;
  if (discriminant < 0)
  {
    *solutions_c = 0;
    return;
  }

  solutions[0] = (-B + sqrt(discriminant)) / (2.0 * A);
  *solutions_c = 1;

  if (discriminant > 0)
  {
    solutions[1] = (-B - sqrt(discriminant)) / (2.0 * A);
    *solutions_c = 2;
  }
}

struct pointLS *newPLS(struct point3D *p0, double r, double g, double b)
{
  // Allocate a new point light sourse structure. Initialize the light
  // source to the specified RGB colour
  // Note that this is a point light source in that it is a single point
  // in space, if you also want a uniform direction for light over the
  // scene (a so-called directional light) you need to place the
  // light source really far away.

  struct pointLS *ls = (struct pointLS *)calloc(1, sizeof(struct pointLS));
  if (!ls)
    fprintf(stderr, "Out of memory allocating light source!\n");
  else
  {
    memcpy(&ls->p0, p0, sizeof(struct point3D)); // Copy light source location

    ls->col.R = r; // Store light source colour and
    ls->col.G = g; // intensity
    ls->col.B = b;
    ls->areaLs = NULL;
  }
  return (ls);
}

/////////////////////////////////////////////
// Ray and normal transforms
/////////////////////////////////////////////
inline void rayTransform(struct ray3D *ray_orig, struct ray3D *ray_transformed, struct object3D *obj)
{
  // Transforms a ray using the inverse transform for the specified object. This is so that we can
  // use the intersection test for the canonical object. Note that this has to be done carefully!

  double Tinv_noTranslation[4][4];
  memcpy(&Tinv_noTranslation[0][0], &obj->Tinv[0][0], 16 * sizeof(double));
  Tinv_noTranslation[0][3] = 0;
  Tinv_noTranslation[1][3] = 0;
  Tinv_noTranslation[2][3] = 0;

  // Transform the ray
  *ray_transformed = *ray_orig;
  matVecMult(Tinv_noTranslation, &ray_transformed->d);
  matVecMult(obj->Tinv, &ray_transformed->p0);
}

inline void normalTransform(struct point3D *n_orig, struct point3D *n_transformed, struct object3D *obj)
{
  // Computes the normal at an affinely transformed point given the original normal and the
  // object's inverse transformation. From the notes:
  // n_transformed=A^-T*n normalized.

  double Tinv_transpose[4][4];
  memcpy(&Tinv_transpose[0][0], &obj->Tinv[0][0], 16 * sizeof(double));
  Tinv_transpose[0][3] = 0;
  Tinv_transpose[1][3] = 0;
  Tinv_transpose[2][3] = 0;
  MatTranspose(Tinv_transpose);
  *n_transformed = *n_orig;
  matVecMult(Tinv_transpose, n_transformed);
}

/////////////////////////////////////////////
// Object management section
/////////////////////////////////////////////
void insertObject(struct object3D *o, struct object3D **list)
{
  if (o == NULL)
    return;
  // Inserts an object into the object list.
  if (*(list) == NULL)
  {
    *(list) = o;
    (*(list))->next = NULL;
  }
  else
  {
    o->next = (*(list))->next;
    (*(list))->next = o;
  }
}

struct object3D *newPlane(double ra, double rd, double rs, double rg, double r, double g, double b, double alpha, double r_index, double shiny)
{
  // Intialize a new plane with the specified parameters:
  // ra, rd, rs, rg - Albedos for the components of the Phong model
  // r, g, b, - Colour for this plane
  // alpha - Transparency, must be set to 1 unless you are doing refraction
  // r_index - Refraction index if you are doing refraction.
  // shiny - Exponent for the specular component of the Phong model
  //
  // The plane is defined by the following vertices (CCW)
  // (1,1,0), (-1,1,0), (-1,-1,0), (1,-1,0)
  // With normal vector (0,0,1) (i.e. parallel to the XY plane)

  struct object3D *plane = (struct object3D *)calloc(1, sizeof(struct object3D));

  if (!plane)
    fprintf(stderr, "Unable to allocate new plane, out of memory!\n");
  else
  {
    plane->alb.ra = ra;
    plane->alb.rd = rd;
    plane->alb.rs = rs;
    plane->alb.rg = rg;
    plane->col.R = r;
    plane->col.G = g;
    plane->col.B = b;
    plane->alpha = alpha;
    plane->r_index = r_index;
    plane->shinyness = shiny;
    plane->intersect = &planeIntersect;
    plane->surfaceCoords = &planeCoordinates;
    plane->randomPoint = &planeSample;
    plane->texImg = NULL;
    plane->photonMap = NULL;
    plane->normalMap = NULL;
    memcpy(&plane->T[0][0], &eye4x4[0][0], 16 * sizeof(double));
    memcpy(&plane->Tinv[0][0], &eye4x4[0][0], 16 * sizeof(double));
    plane->textureMap = &texMap;
    plane->frontAndBack = 1;
    plane->photonMapped = 0;
    plane->normalMapped = 0;
    plane->isCSG = 0;
    plane->isLightSource = 0;
    plane->CSGnext = NULL;
    plane->next = NULL;
  }
  return (plane);
}

struct object3D *newSphere(double ra, double rd, double rs, double rg, double r, double g, double b, double alpha, double r_index, double shiny)
{
  // Intialize a new sphere with the specified parameters:
  // ra, rd, rs, rg - Albedos for the components of the Phong model
  // r, g, b, - Colour for this plane
  // alpha - Transparency, must be set to 1 unless you are doing refraction
  // r_index - Refraction index if you are doing refraction.
  // shiny -Exponent for the specular component of the Phong model
  //
  // This is assumed to represent a unit sphere centered at the origin.
  //

  struct object3D *sphere = (struct object3D *)calloc(1, sizeof(struct object3D));

  if (!sphere)
    fprintf(stderr, "Unable to allocate new sphere, out of memory!\n");
  else
  {
    sphere->alb.ra = ra;
    sphere->alb.rd = rd;
    sphere->alb.rs = rs;
    sphere->alb.rg = rg;
    sphere->col.R = r;
    sphere->col.G = g;
    sphere->col.B = b;
    sphere->alpha = alpha;
    sphere->r_index = r_index;
    sphere->shinyness = shiny;
    sphere->intersect = &sphereIntersect;
    sphere->surfaceCoords = &sphereCoordinates;
    sphere->randomPoint = &sphereSample;
    sphere->texImg = NULL;
    sphere->photonMap = NULL;
    sphere->normalMap = NULL;
    memcpy(&sphere->T[0][0], &eye4x4[0][0], 16 * sizeof(double));
    memcpy(&sphere->Tinv[0][0], &eye4x4[0][0], 16 * sizeof(double));
    sphere->textureMap = &texMap;
    sphere->frontAndBack = 0;
    sphere->photonMapped = 0;
    sphere->normalMapped = 0;
    sphere->isCSG = 0;
    sphere->isLightSource = 0;
    sphere->CSGnext = NULL;
    sphere->next = NULL;
  }
  return (sphere);
}

struct object3D *newCyl(double ra, double rd, double rs, double rg, double r, double g, double b, double alpha, double r_index, double shiny)
{
  struct object3D *cyl = (struct object3D *)calloc(1, sizeof(struct object3D));

  if (!cyl)
    fprintf(stderr, "Unable to allocate new cylinder, out of memory!\n");
  else
  {
    cyl->alb.ra = ra;
    cyl->alb.rd = rd;
    cyl->alb.rs = rs;
    cyl->alb.rg = rg;
    cyl->col.R = r;
    cyl->col.G = g;
    cyl->col.B = b;
    cyl->alpha = alpha;
    cyl->r_index = r_index;
    cyl->shinyness = shiny;
    cyl->intersect = &cylIntersect;
    cyl->surfaceCoords = &cylCoordinates;
    cyl->randomPoint = &cylSample;
    cyl->texImg = NULL;
    cyl->photonMap = NULL;
    cyl->normalMap = NULL;
    memcpy(&cyl->T[0][0], &eye4x4[0][0], 16 * sizeof(double));
    memcpy(&cyl->Tinv[0][0], &eye4x4[0][0], 16 * sizeof(double));
    cyl->textureMap = &texMap;
    cyl->frontAndBack = 0;
    cyl->photonMapped = 0;
    cyl->normalMapped = 0;
    cyl->isCSG = 0;
    cyl->isLightSource = 0;
    cyl->CSGnext = NULL;
    cyl->next = NULL;
  }
  return (cyl);
}

void planeIntersect(struct object3D *plane, struct ray3D *ray, double *lambda, struct point3D *p, struct point3D *n, double *a, double *b)
{
  // Computes and returns the value of 'lambda' at the intersection
  // between the specified ray and the specified canonical plane.

  struct ray3D ray_transformed;
  rayTransform(ray, &ray_transformed, plane);

  /* Derivation:
   * Plane: p(alpha, beta) = [1 0 0] * alpha + [0 1 0] * beta
   * Line: r(lambda) = r0 + lambda * d
   *
   * r0 + lambda * d = alpha * [1 0 0] + beta * [0 1 0]
   * r0 + lambda * d = [alpha beta 0]
   * lambda * d = [alpha - r0_x, beta - r0_y, -r0_z]
   * => -r0_z = lambda * d_x <=> lambda = -r0_z / d_x
   * and alpha/beta are retrieved by plugging lambda back in and solving
   */
  *lambda = -ray_transformed.p0.pz / ray_transformed.d.pz;
  double alpha = ray_transformed.p0.px + (*lambda) * ray_transformed.d.px;
  double beta = ray_transformed.p0.py + (*lambda) * ray_transformed.d.py;

  if (*lambda < TOL)
  {
    // lambda is zero or negative
    *lambda = INFINITY;
    return;
  }

  if (!(fabs(alpha) >= 0 && fabs(alpha) <= 1 && fabs(beta) >= 0 && fabs(beta) <= 1))
  {                     // alpha, beta not E [-1, 1]
    *lambda = INFINITY; // outside of bounds
    return;
  }

  rayPosition(ray, *lambda, p);
  struct point3D plane_normal = {.px = 0, .py = 0, .pz = 1, .pw = 1};
  normalTransform(&plane_normal, n, plane);
  normalize(n);

  // Assign a, b
  struct point3D pt_on_canonical_plane;
  rayPosition(&ray_transformed, *lambda, &pt_on_canonical_plane);
  *a = alpha / 2.0 + 0.5;
  *b = beta / 2.0 + 0.5;
}

void sphereIntersect(struct object3D *sphere, struct ray3D *ray, double *lambda, struct point3D *p, struct point3D *n, double *a, double *b)
{
  // Computes and returns the value of 'lambda' at the intersection
  // between the specified ray and the specified canonical sphere.

  // Get instance of transformation matrix WITHOUT translation
  struct ray3D ray_transformed;
  rayTransform(ray, &ray_transformed, sphere);
  *lambda = INFINITY;

  // d (*) d
  double A = dot(&ray_transformed.d, &ray_transformed.d);
  // At origin, so (a - c) (*) d <=> a (*) d
  double B = dot(&ray_transformed.d, &ray_transformed.p0);
  // At origin, with radius 1, so (a - c) (*) (a - c) - 1 <=> a (*) a - 1
  double C = dot(&ray_transformed.p0, &ray_transformed.p0) - 1.0;

  // Allocate memory for solutions array
  double solutions[2];
  int solutions_c = 0;

  double disc = pow(B, 2) - A * C;
  if (disc >= 0)
    solutions_c++;
  if (disc > 0)
    solutions_c++;

  solutions[0] = -B / A + sqrt(disc) / A;
  solutions[1] = -B / A - sqrt(disc) / A;

  if (solutions_c == 0)
  {
    return; // No solution
  }

  if (solutions_c == 1 && solutions[0] > 0)
  {
    *lambda = solutions[0];
  }

  if (solutions_c == 2)
  {
    // Check which lambda is smaller and greater than 0
    *lambda = min(max(0.0, solutions[0]), max(0.0, solutions[1]));
  }

  rayPosition(ray, *lambda, p);

  // Take the POI and transform it
  struct point3D normal_on_unit_sphere;
  rayPosition(&ray_transformed, *lambda, &normal_on_unit_sphere);
  normalize(&normal_on_unit_sphere);
  normalTransform(&normal_on_unit_sphere, n, sphere);
  normalize(n);

  // Determine a, b texture coordinates by using the POI to determine the parametrization
  struct point3D pt_on_unit_sphere;
  rayPosition(&ray_transformed, *lambda, &pt_on_unit_sphere);
  double u = acos(pt_on_unit_sphere.pz);
  double v = acos(pt_on_unit_sphere.px / sin(u));
  *a = max(min(1.0, u / PI), 0.0);
  *b = max(min(1.0, v / (2 * PI)), 0.0);
}

void cylIntersect(struct object3D *cylinder, struct ray3D *ray, double *lambda, struct point3D *p, struct point3D *n, double *a, double *b)
{
  // Computes and returns the value of 'lambda' at the intersection
  // between the specified ray and the specified canonical cylinder.

  struct ray3D ray_transformed;
  rayTransform(ray, &ray_transformed, cylinder);
  *lambda = INFINITY;

  struct ray3D ray_transformed_without_z = ray_transformed;
  ray_transformed_without_z.p0.pz = 0.0;
  ray_transformed_without_z.d.pz = 0.0;

  double A = dot(&ray_transformed_without_z.d, &ray_transformed_without_z.d);
  double B = 2.0 * dot(&ray_transformed_without_z.p0, &ray_transformed_without_z.d);
  double C = dot(&ray_transformed_without_z.p0, &ray_transformed_without_z.p0) - 1.0;

  double solutions[2];
  int solution_c;
  solveQuadratic(A, B, C, solutions, &solution_c);

  double candidate_solns[4];
  struct point3D candidate_norms[4];
  int candidate_soln_c = 0; // Number of possible solutions

  for (int soln_idx = 0; soln_idx < solution_c; soln_idx++)
  {
    struct point3D temp_pt;
    rayPosition(&ray_transformed, solutions[soln_idx], &temp_pt);

    // Verify that the point meets constraints
    if (fabs(ray_transformed.p0.pz + ray_transformed.d.pz * solutions[soln_idx]) < 1)
    {
      candidate_solns[candidate_soln_c] = solutions[soln_idx];
      candidate_norms[candidate_soln_c] = temp_pt;
      candidate_soln_c++;
    }
  }

  // Check for intersections with top/bottom of cylinder at z=-1 and z=1
  double z_val[2] = {-1, 1};
  for (int z_idx = 0; z_idx < 2; z_idx++)
  {
    // Initialize plane
    struct object3D *cyl_plane = newPlane(0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
    Translate(cyl_plane, 0, 0, z_val[z_idx]);
    invert(&cyl_plane->T[0][0], &cyl_plane->Tinv[0][0]);
    double ta, tb;

    // Intersect
    double circ_lambda;
    struct point3D circ_poi, circ_norm;
    cyl_plane->intersect(cyl_plane, &ray_transformed, &circ_lambda, &circ_poi, &circ_norm, &ta, &tb);

    if (circ_lambda < INFINITY)
    {
      struct point3D temp_pt;
      rayPosition(&ray_transformed, circ_lambda, &temp_pt);
      if ((pow(temp_pt.px, 2) + pow(temp_pt.py, 2)) < 1)
      {
        candidate_solns[candidate_soln_c] = circ_lambda;
        candidate_norms[candidate_soln_c] = circ_norm;
        candidate_soln_c++;
      }
    }

    free(cyl_plane);
  }

  int best_idx = 0;
  // Find best solution
  for (int soln_idx = 0; soln_idx < candidate_soln_c; soln_idx++)
  {
    if (candidate_solns[soln_idx] < candidate_solns[best_idx])
    {
      best_idx = soln_idx;
    }
  }

  if (candidate_soln_c > 0)
  {
    rayPosition(ray, candidate_solns[best_idx], p);
    normalize(&candidate_norms[best_idx]);
    normalTransform(&candidate_norms[best_idx], n, cylinder);
    *lambda = candidate_solns[best_idx];

    // Determine a, b texture coordinates by using the POI to determine the parametrization
    struct point3D pt_on_unit_cyl;
    rayPosition(&ray_transformed, *lambda, &pt_on_unit_cyl);
    double u = acos(pt_on_unit_cyl.px);
    double v = pt_on_unit_cyl.pz;
    *a = max(min(1.0, u), 0.0);
    *b = max(min(1.0, v / (2 * PI)), 0.0);
  }
}

/////////////////////////////////////////////////////////////////
// Surface coordinates & random sampling on object surfaces
/////////////////////////////////////////////////////////////////
void planeCoordinates(struct object3D *plane, double a, double b, double *x, double *y, double *z)
{
  // Return in (x,y,z) the coordinates of a point on the plane given by the 2 parameters a,b in [0,1].
  // 'a' controls displacement from the left side of the plane, 'b' controls displacement from the
  // bottom of the plane.

  // Assume a plane with vectors [1 0 0] and [0 1 0] with normal [0 0 1] and pt [0 0 0]
  struct point3D temp_pt;
  temp_pt.px = a;
  temp_pt.py = b;
  temp_pt.pz = 0;
  temp_pt.pw = 1;
  matVecMult(plane->T, &temp_pt);

  *x = temp_pt.px;
  *y = temp_pt.py;
  *z = temp_pt.pz;
}

void sphereCoordinates(struct object3D *sphere, double a, double b, double *x, double *y, double *z)
{
  // Return in (x,y,z) the coordinates of a point on the plane given by the 2 parameters a,b.
  // 'a' in [0, 2*PI] corresponds to the spherical coordinate theta
  // 'b' in [-PI/2, PI/2] corresponds to the spherical coordinate phi

  struct point3D pt;
  pt.px = cos(a) * sin(b);
  pt.py = sin(a) * sin(b);
  pt.pz = cos(b);

  matVecMult(sphere->T, &pt);
  *x = pt.px;
  *y = pt.py;
  *z = pt.pz;
}

void cylCoordinates(struct object3D *cyl, double a, double b, double *x, double *y, double *z)
{
  // Return in (x,y,z) the coordinates of a point on the plane given by the 2 parameters a,b.
  // 'a' in [0, 2*PI] corresponds to angle theta around the cylinder
  // 'b' in [0, 1] corresponds to height from the bottom

  struct point3D pt;
  pt.px = cos(a);
  pt.py = sin(a);
  pt.pz = b;

  matVecMult(cyl->T, &pt);
  *x = pt.px;
  *y = pt.py;
  *z = pt.pz;
}

void planeSample(struct object3D *plane, double *x, double *y, double *z)
{
  // Returns the 3D coordinates (x,y,z) of a randomly sampled point on the plane
  // Sapling should be uniform, meaning there should be an equal change of gedtting
  // any spot on the plane

  double a = (double)rand() / (double)RAND_MAX;
  double b = (double)rand() / (double)RAND_MAX;

  planeCoordinates(plane, a, b, x, y, z);
}

void sphereSample(struct object3D *sphere, double *x, double *y, double *z)
{
  // Returns the 3D coordinates (x,y,z) of a randomly sampled point on the sphere
  // Sampling should be uniform - note that this is tricky for a sphere, do some
  // research and document in your report what method is used to do this, along
  // with a reference to your source.

  // https://mathworld.wolfram.com/SpherePointPicking.html

  double u = (double)rand() / (double)RAND_MAX;
  double v = (double)rand() / (double)RAND_MAX;
  double theta = 2 * PI * u;
  double phi = acos(2 * v - 1);

  sphereCoordinates(sphere, theta, phi, x, y, z);
}

void cylSample(struct object3D *cyl, double *x, double *y, double *z)
{
  // Returns the 3D coordinates (x,y,z) of a randomly sampled point on the cylinder
  // Sampling should be uniform over the cylinder.

  double a = ((double)rand() / (double)RAND_MAX) * 2 * PI;
  double b = ((double)rand() / (double)RAND_MAX);

  cylCoordinates(cyl, a, b, x, y, z);
}

/////////////////////////////////
// Texture mapping functions
/////////////////////////////////
void loadTexture(struct object3D *o, const char *filename, int type, struct textureNode **t_list)
{
  // Load a texture or normal map image from file and assign it to the
  // specified object.
  // type:   1  ->  Texture map  (RGB, .ppm)
  //         2  ->  Normal map   (RGB, .ppm)
  //         3  ->  Alpha map    (grayscale, .pgm)
  // Stores loaded images in a linked list to avoid replication
  struct image *im;
  struct textureNode *p;

  if (o != NULL)
  {
    // Check current linked list
    p = *(t_list);
    while (p != NULL)
    {
      if (strcmp(&p->name[0], filename) == 0)
      {
        // Found image already on the list
        if (type == 1)
          o->texImg = p->im;
        else if (type == 2)
          o->normalMap = p->im;
        else
          o->alphaMap = p->im;
        return;
      }
      p = p->next;
    }

    // Load this texture image
    if (type == 1 || type == 2)
      im = readPPMimage(filename);
    else if (type == 3)
      im = readPGMimage(filename);

    // Insert it into the texture list
    if (im != NULL)
    {
      p = (struct textureNode *)calloc(1, sizeof(struct textureNode));
      strcpy(&p->name[0], filename);
      p->type = type;
      p->im = im;
      p->next = NULL;
      // Insert into linked list
      if ((*(t_list)) == NULL)
        *(t_list) = p;
      else
      {
        p->next = (*(t_list))->next;
        (*(t_list))->next = p;
      }
      // Assign to object
      if (type == 1)
        o->texImg = im;
      else if (type == 2)
        o->normalMap = im;
      else
        o->alphaMap = im;
    }

  } // end if (o != NULL)
}

void texMap(struct image *img, double a, double b, double *R, double *G, double *B)
{
  /*
   Function to determine the colour of a textured object at
   the normalized texture coordinates (a,b).

   a and b are texture coordinates in [0 1].
   img is a pointer to the image structure holding the texture for
    a given object.

   The colour is returned in R, G, B. Uses bi-linear interpolation
   to determine texture colour.
  */

  int pt_x = a * (img->sx - 1);
  int pt_y = b * (img->sy - 1);

  // printf("size: %d %d\n", img->sx, img->sy);
  // printf("%f, %f -> %d, %d\n", a, b, pt_x, pt_y);

  double *rgbdata = (double *)img->rgbdata;

  double tr = (double)rgbdata[(img->sx * pt_y + pt_x) * 3];
  double tg = (double)rgbdata[(img->sx * pt_y + pt_x) * 3 + 1];
  double tb = (double)rgbdata[(img->sx * pt_y + pt_x) * 3 + 2];

  //////////////////////////////////////////////////
  // TO DO (Assignment 4 only):
  //
  //  Complete this function to return the colour
  // of the texture image at the specified texture
  // coordinates. Your code should use bi-linear
  // interpolation to obtain the texture colour.
  //////////////////////////////////////////////////

  // printf("col %f %f %f\n", tr, tg, tb);

  *R = tr;
  *G = tg;
  *B = tb;

  return;
}

void alphaMap(struct image *img, double a, double b, double *alpha)
{
  // Just like texture map but returns the alpha value at a,b,
  // notice that alpha maps are single layer grayscale images, hence
  // the separate function.

  int pt_x = a * (img->sx - 1);
  int pt_y = b * (img->sy - 1);

  // printf("size: %d %d\n", img->sx, img->sy);
  // printf("%f, %f -> %d, %d\n", a, b, pt_x, pt_y);

  double *rgbdata = (double *)img->rgbdata;

  *alpha = (double)rgbdata[(img->sx * pt_y + pt_x)];

  return;
}

/////////////////////////////
// Light sources
/////////////////////////////
void insertPLS(struct pointLS *l, struct pointLS **list)
{
  if (l == NULL)
    return;
  // Inserts a light source into the list of light sources
  if (*(list) == NULL)
  {
    *(list) = l;
    (*(list))->next = NULL;
  }
  else
  {
    l->next = (*(list))->next;
    (*(list))->next = l;
  }
}

void addObjectAreaLight(struct object3D *obj, int N,
                        double r, double g, double b, struct pointLS **l_list)
{
  /**
   * addObjectAreaLight: obj is an object to act as a light source;
   * r, g, b are the colours;
   * l_list is a pointer to the light source list pointer.
   */
  struct point3D ls_pt;
  ls_pt.px = 0;
  ls_pt.py = 0;
  ls_pt.pz = 0;
  ls_pt.pw = 1;

  // Create light source point
  struct pointLS *ls = (struct pointLS *)calloc(1, sizeof(struct pointLS));
  ls->col.R = r;
  ls->col.G = g;
  ls->col.B = b;
  obj->col.R = r;
  obj->col.G = g;
  obj->col.B = b;
  ls->p0 = ls_pt;
  ls->areaLs = obj;
  ls->lsSamples = N;
  obj->isLightSource = 1;
  insertPLS(ls, l_list);
}

///////////////////////////////////
// Geometric transformation section
///////////////////////////////////

void invert(double *T, double *Tinv)
{
  // Computes the inverse of transformation matrix T.
  // the result is returned in Tinv.

  double *U, *s, *V, *rv1;
  int singFlag, i;

  // Invert the affine transform
  U = NULL;
  s = NULL;
  V = NULL;
  rv1 = NULL;
  singFlag = 0;

  SVD(T, 4, 4, &U, &s, &V, &rv1);
  if (U == NULL || s == NULL || V == NULL)
  {
    fprintf(stderr, "Error: Matrix not invertible for this object, returning identity\n");
    memcpy(Tinv, eye4x4, 16 * sizeof(double));
    return;
  }

  // Check for singular matrices...
  for (i = 0; i < 4; i++)
    if (*(s + i) < 1e-9)
      singFlag = 1;
  if (singFlag)
  {
    fprintf(stderr, "Error: Transformation matrix is singular, returning identity\n");
    memcpy(Tinv, eye4x4, 16 * sizeof(double));
    return;
  }

  // Compute and store inverse matrix
  InvertMatrix(U, s, V, 4, Tinv);

  free(U);
  free(s);
  free(V);
}

void RotateXMat(double T[4][4], double theta)
{
  // Multiply the current object transformation matrix T in object o
  // by a matrix that rotates the object theta *RADIANS* around the
  // X axis.

  double R[4][4];
  memset(&R[0][0], 0, 16 * sizeof(double));

  R[0][0] = 1.0;
  R[1][1] = cos(theta);
  R[1][2] = -sin(theta);
  R[2][1] = sin(theta);
  R[2][2] = cos(theta);
  R[3][3] = 1.0;

  matMult(R, T);
}

void RotateX(struct object3D *o, double theta)
{
  // Multiply the current object transformation matrix T in object o
  // by a matrix that rotates the object theta *RADIANS* around the
  // X axis.

  double R[4][4];
  memset(&R[0][0], 0, 16 * sizeof(double));

  R[0][0] = 1.0;
  R[1][1] = cos(theta);
  R[1][2] = -sin(theta);
  R[2][1] = sin(theta);
  R[2][2] = cos(theta);
  R[3][3] = 1.0;

  matMult(R, o->T);
}

void RotateYMat(double T[4][4], double theta)
{
  // Multiply the current object transformation matrix T in object o
  // by a matrix that rotates the object theta *RADIANS* around the
  // Y axis.

  double R[4][4];
  memset(&R[0][0], 0, 16 * sizeof(double));

  R[0][0] = cos(theta);
  R[0][2] = sin(theta);
  R[1][1] = 1.0;
  R[2][0] = -sin(theta);
  R[2][2] = cos(theta);
  R[3][3] = 1.0;

  matMult(R, T);
}

void RotateY(struct object3D *o, double theta)
{
  // Multiply the current object transformation matrix T in object o
  // by a matrix that rotates the object theta *RADIANS* around the
  // Y axis.

  double R[4][4];
  memset(&R[0][0], 0, 16 * sizeof(double));

  R[0][0] = cos(theta);
  R[0][2] = sin(theta);
  R[1][1] = 1.0;
  R[2][0] = -sin(theta);
  R[2][2] = cos(theta);
  R[3][3] = 1.0;

  matMult(R, o->T);
}

void RotateZMat(double T[4][4], double theta)
{
  // Multiply the current object transformation matrix T in object o
  // by a matrix that rotates the object theta *RADIANS* around the
  // Z axis.

  double R[4][4];
  memset(&R[0][0], 0, 16 * sizeof(double));

  R[0][0] = cos(theta);
  R[0][1] = -sin(theta);
  R[1][0] = sin(theta);
  R[1][1] = cos(theta);
  R[2][2] = 1.0;
  R[3][3] = 1.0;

  matMult(R, T);
}

void RotateZ(struct object3D *o, double theta)
{
  // Multiply the current object transformation matrix T in object o
  // by a matrix that rotates the object theta *RADIANS* around the
  // Z axis.

  double R[4][4];
  memset(&R[0][0], 0, 16 * sizeof(double));

  R[0][0] = cos(theta);
  R[0][1] = -sin(theta);
  R[1][0] = sin(theta);
  R[1][1] = cos(theta);
  R[2][2] = 1.0;
  R[3][3] = 1.0;

  matMult(R, o->T);
}

void TranslateMat(double T[4][4], double tx, double ty, double tz)
{
  // Multiply the current object transformation matrix T in object o
  // by a matrix that translates the object by the specified amounts.

  double tr[4][4];
  memset(&tr[0][0], 0, 16 * sizeof(double));

  tr[0][0] = 1.0;
  tr[1][1] = 1.0;
  tr[2][2] = 1.0;
  tr[0][3] = tx;
  tr[1][3] = ty;
  tr[2][3] = tz;
  tr[3][3] = 1.0;

  matMult(tr, T);
}

void Translate(struct object3D *o, double tx, double ty, double tz)
{
  // Multiply the current object transformation matrix T in object o
  // by a matrix that translates the object by the specified amounts.

  double tr[4][4];
  memset(&tr[0][0], 0, 16 * sizeof(double));

  tr[0][0] = 1.0;
  tr[1][1] = 1.0;
  tr[2][2] = 1.0;
  tr[0][3] = tx;
  tr[1][3] = ty;
  tr[2][3] = tz;
  tr[3][3] = 1.0;

  matMult(tr, o->T);
}

void ScaleMat(double T[4][4], double sx, double sy, double sz)
{
  // Multiply the current object transformation matrix T in object o
  // by a matrix that scales the object as indicated.

  double S[4][4];
  memset(&S[0][0], 0, 16 * sizeof(double));

  S[0][0] = sx;
  S[1][1] = sy;
  S[2][2] = sz;
  S[3][3] = 1.0;

  matMult(S, T);
}

void Scale(struct object3D *o, double sx, double sy, double sz)
{
  // Multiply the current object transformation matrix T in object o
  // by a matrix that scales the object as indicated.

  double S[4][4];
  memset(&S[0][0], 0, 16 * sizeof(double));

  S[0][0] = sx;
  S[1][1] = sy;
  S[2][2] = sz;
  S[3][3] = 1.0;

  matMult(S, o->T);
}

void printmatrix(double mat[4][4])
{
  fprintf(stderr, "Matrix contains:\n");
  fprintf(stderr, "%f %f %f %f\n", mat[0][0], mat[0][1], mat[0][2], mat[0][3]);
  fprintf(stderr, "%f %f %f %f\n", mat[1][0], mat[1][1], mat[1][2], mat[1][3]);
  fprintf(stderr, "%f %f %f %f\n", mat[2][0], mat[2][1], mat[2][2], mat[2][3]);
  fprintf(stderr, "%f %f %f %f\n", mat[3][0], mat[3][1], mat[3][2], mat[3][3]);
}

/////////////////////////////////////////
// Camera and view setup
/////////////////////////////////////////
struct view *setupView(struct point3D *e, struct point3D *g, struct point3D *up, double f, double wl, double wt, double wsize)
{
  /*
    This function sets up the camera axes and viewing direction as discussed in the
    lecture notes.
    e - Camera center
    g - Gaze direction
    up - Up vector
    fov - Fild of view in degrees
    f - focal length
  */
  struct view *c;
  struct point3D *u, *v;

  u = v = NULL;

  // Allocate space for the camera structure
  c = (struct view *)calloc(1, sizeof(struct view));
  if (c == NULL)
  {
    fprintf(stderr, "Out of memory setting up camera model!\n");
    return (NULL);
  }

  // Set up camera center and axes
  c->e.px = e->px; // Copy camera center location, note we must make sure
  c->e.py = e->py; // the camera center provided to this function has pw=1
  c->e.pz = e->pz;
  c->e.pw = 1;

  // Set up w vector (camera's Z axis). w=-g/||g||
  c->w.px = -g->px;
  c->w.py = -g->py;
  c->w.pz = -g->pz;
  c->w.pw = 1;
  normalize(&c->w);

  // Set up the horizontal direction, which must be perpenticular to w and up
  u = cross(&c->w, up);
  normalize(u);
  c->u.px = u->px;
  c->u.py = u->py;
  c->u.pz = u->pz;
  c->u.pw = 1;

  // Set up the remaining direction, v=(u x w)  - Mind the signs
  v = cross(&c->u, &c->w);
  normalize(v);
  c->v.px = v->px;
  c->v.py = v->py;
  c->v.pz = v->pz;
  c->v.pw = 1;

  // Copy focal length and window size parameters
  c->f = f;
  c->wl = wl;
  c->wt = wt;
  c->wsize = wsize;

  // Set up coordinate conversion matrices
  // Camera2World matrix (M_cw in the notes)
  // Mind the indexing convention [row][col]
  c->C2W[0][0] = c->u.px;
  c->C2W[1][0] = c->u.py;
  c->C2W[2][0] = c->u.pz;
  c->C2W[3][0] = 0;

  c->C2W[0][1] = c->v.px;
  c->C2W[1][1] = c->v.py;
  c->C2W[2][1] = c->v.pz;
  c->C2W[3][1] = 0;

  c->C2W[0][2] = c->w.px;
  c->C2W[1][2] = c->w.py;
  c->C2W[2][2] = c->w.pz;
  c->C2W[3][2] = 0;

  c->C2W[0][3] = c->e.px;
  c->C2W[1][3] = c->e.py;
  c->C2W[2][3] = c->e.pz;
  c->C2W[3][3] = 1;

  // World2Camera matrix (M_wc in the notes)
  // Mind the indexing convention [row][col]
  c->W2C[0][0] = c->u.px;
  c->W2C[1][0] = c->v.px;
  c->W2C[2][0] = c->w.px;
  c->W2C[3][0] = 0;

  c->W2C[0][1] = c->u.py;
  c->W2C[1][1] = c->v.py;
  c->W2C[2][1] = c->w.py;
  c->W2C[3][1] = 0;

  c->W2C[0][2] = c->u.pz;
  c->W2C[1][2] = c->v.pz;
  c->W2C[2][2] = c->w.pz;
  c->W2C[3][2] = 0;

  c->W2C[0][3] = -dot(&c->u, &c->e);
  c->W2C[1][3] = -dot(&c->v, &c->e);
  c->W2C[2][3] = -dot(&c->w, &c->e);
  c->W2C[3][3] = 1;

  free(u);
  free(v);
  return (c);
}

/////////////////////////////////////////
// Image I/O section
/////////////////////////////////////////
struct image *readPPMimage(const char *filename)
{
  // Reads an image from a .ppm file. A .ppm file is a very simple image representation
  // format with a text header followed by the binary RGB data at 24bits per pixel.
  // The header has the following form:
  //
  // P6
  // # One or more comment lines preceded by '#'
  // 340 200
  // 255
  //
  // The first line 'P6' is the .ppm format identifier, this is followed by one or more
  // lines with comments, typically used to inidicate which program generated the
  // .ppm file.
  // After the comments, a line with two integer values specifies the image resolution
  // as number of pixels in x and number of pixels in y.
  // The final line of the header stores the maximum value for pixels in the image,
  // usually 255.
  // After this last header line, binary data stores the RGB values for each pixel
  // in row-major order. Each pixel requires 3 bytes ordered R, G, and B.
  //
  // NOTE: Windows file handling is rather crotchetty. You may have to change the
  //       way this file is accessed if the images are being corrupted on read
  //       on Windows.
  //
  // readPPMdata converts the image colour information to floating point. This is so that
  // the texture mapping function doesn't have to do the conversion every time
  // it is asked to return the colour at a specific location.
  //

  FILE *f;
  struct image *im;
  char line[1024];
  int sizx, sizy;
  int i;
  unsigned char *tmp;
  double *fRGB;
  int tmpi;
  char *tmpc;

  im = (struct image *)calloc(1, sizeof(struct image));
  if (im != NULL)
  {
    im->rgbdata = NULL;
    f = fopen(filename, "rb+");
    if (f == NULL)
    {
      fprintf(stderr, "Unable to open file %s for reading, please check name and path\n", filename);
      free(im);
      return (NULL);
    }
    tmpc = fgets(&line[0], 1000, f);
    if (strcmp(&line[0], "P6\n") != 0)
    {
      fprintf(stderr, "Wrong file format, not a .ppm file or header end-of-line characters missing\n");
      free(im);
      fclose(f);
      return (NULL);
    }
    fprintf(stderr, "%s\n", line);
    // Skip over comments
    tmpc = fgets(&line[0], 511, f);
    while (line[0] == '#')
    {
      fprintf(stderr, "%s", line);
      tmpc = fgets(&line[0], 511, f);
    }
    sscanf(&line[0], "%d %d\n", &sizx, &sizy); // Read file size
    fprintf(stderr, "nx=%d, ny=%d\n\n", sizx, sizy);
    im->sx = sizx;
    im->sy = sizy;

    tmpc = fgets(&line[0], 9, f); // Read the remaining header line
    fprintf(stderr, "%s\n", line);
    tmp = (unsigned char *)calloc(sizx * sizy * 3, sizeof(unsigned char));
    fRGB = (double *)calloc(sizx * sizy * 3, sizeof(double));
    if (tmp == NULL || fRGB == NULL)
    {
      fprintf(stderr, "Out of memory allocating space for image\n");
      free(im);
      fclose(f);
      return (NULL);
    }

    tmpi = fread(tmp, sizx * sizy * 3 * sizeof(unsigned char), 1, f);
    fclose(f);

    // Conversion to floating point
    for (i = 0; i < sizx * sizy * 3; i++)
      *(fRGB + i) = ((double)*(tmp + i)) / 255.0;
    free(tmp);
    im->rgbdata = (void *)fRGB;

    return (im);
  }

  fprintf(stderr, "Unable to allocate memory for image structure\n");
  return (NULL);
}

struct image *readPGMimage(const char *filename)
{
  // Just like readPPMimage() except it is used to load grayscale alpha maps. In
  // alpha maps, a value of 255 corresponds to alpha=1 (fully opaque) and 0
  // correspondst to alpha=0 (fully transparent).
  // A .pgm header of the following form is expected:
  //
  // P5
  // # One or more comment lines preceded by '#'
  // 340 200
  // 255
  //
  // readPGMdata converts the image grayscale data to double floating point in [0,1].

  FILE *f;
  struct image *im;
  char line[1024];
  int sizx, sizy;
  int i;
  unsigned char *tmp;
  double *fRGB;
  int tmpi;
  char *tmpc;

  im = (struct image *)calloc(1, sizeof(struct image));
  if (im != NULL)
  {
    im->rgbdata = NULL;
    f = fopen(filename, "rb+");
    if (f == NULL)
    {
      fprintf(stderr, "Unable to open file %s for reading, please check name and path\n", filename);
      free(im);
      return (NULL);
    }
    tmpc = fgets(&line[0], 1000, f);
    if (strcmp(&line[0], "P5\n") != 0)
    {
      fprintf(stderr, "Wrong file format, not a .pgm file or header end-of-line characters missing\n");
      free(im);
      fclose(f);
      return (NULL);
    }
    // Skip over comments
    tmpc = fgets(&line[0], 511, f);
    while (line[0] == '#')
      tmpc = fgets(&line[0], 511, f);
    sscanf(&line[0], "%d %d\n", &sizx, &sizy); // Read file size
    im->sx = sizx;
    im->sy = sizy;

    tmpc = fgets(&line[0], 9, f); // Read the remaining header line
    tmp = (unsigned char *)calloc(sizx * sizy, sizeof(unsigned char));
    fRGB = (double *)calloc(sizx * sizy, sizeof(double));
    if (tmp == NULL || fRGB == NULL)
    {
      fprintf(stderr, "Out of memory allocating space for image\n");
      free(im);
      fclose(f);
      return (NULL);
    }

    tmpi = fread(tmp, sizx * sizy * sizeof(unsigned char), 1, f);
    fclose(f);

    // Conversion to double floating point
    for (i = 0; i < sizx * sizy; i++)
      *(fRGB + i) = ((double)*(tmp + i)) / 255.0;
    free(tmp);
    im->rgbdata = (void *)fRGB;

    return (im);
  }

  fprintf(stderr, "Unable to allocate memory for image structure\n");
  return (NULL);
}

struct image *newPhotonMap(int sx, int sy)
{
  double *fRGB = (double *)calloc(sx * sy * 3, sizeof(double));

  // Conversion to floating point
  for (int i = 0; i < sx * sy * 3; i++)
    *(fRGB + i) = 0;

  struct image *img = (struct image *)calloc(1, sizeof(struct image));
  img->sx = sx;
  img->sy = sy;
  img->rgbdata = fRGB;

  return img;
}

struct image *newImage(int size_x, int size_y)
{
  // Allocates and returns a new image with all zeros. Assumes 24 bit per pixel,
  // unsigned char array.
  struct image *im;

  im = (struct image *)calloc(1, sizeof(struct image));
  if (im != NULL)
  {
    im->rgbdata = NULL;
    im->sx = size_x;
    im->sy = size_y;
    im->rgbdata = (void *)calloc(size_x * size_y * 3, sizeof(unsigned char));
    if (im->rgbdata != NULL)
      return (im);
  }
  fprintf(stderr, "Unable to allocate memory for new image\n");
  return (NULL);
}

void imageOutput(struct image *im, const char *filename)
{
  // Writes out a .ppm file from the image data contained in 'im'.
  // Note that Windows typically doesn't know how to open .ppm
  // images. Use Gimp or any other seious image processing
  // software to display .ppm images.
  // Also, note that because of Windows file format management,
  // you may have to modify this file to get image output on
  // Windows machines to work properly.
  //
  // Assumes a 24 bit per pixel image stored as unsigned chars
  //

  FILE *f;

  if (im != NULL)
    if (im->rgbdata != NULL)
    {
      f = fopen(filename, "wb+");
      if (f == NULL)
      {
        fprintf(stderr, "Unable to open file %s for output! No image written\n", filename);
        return;
      }
      fprintf(f, "P6\n");
      fprintf(f, "# Output from RayTracer.c\n");
      fprintf(f, "%d %d\n", im->sx, im->sy);
      fprintf(f, "255\n");
      fwrite((unsigned char *)im->rgbdata, im->sx * im->sy * 3 * sizeof(unsigned char), 1, f);
      fclose(f);
      return;
    }
  fprintf(stderr, "imageOutput(): Specified image is empty. Nothing output\n");
}

void deleteImage(struct image *im)
{
  // De-allocates memory reserved for the image stored in 'im'
  if (im != NULL)
  {
    if (im->rgbdata != NULL)
      free(im->rgbdata);
    free(im);
  }
}

void cleanup(struct object3D *o_list, struct pointLS *l_list, struct textureNode *t_list)
{
  // De-allocates memory reserved for the object list and the point light source
  // list. Note that *YOU* must de-allocate any memory reserved for images
  // rendered by the raytracer.
  struct object3D *p, *q;
  struct pointLS *r, *s;
  struct textureNode *t, *u;

  p = o_list; // De-allocate all memory from objects in the list
  while (p != NULL)
  {
    q = p->next;
    if (p->photonMap != NULL) // If object is photon mapped, free photon map memory
    {
      if (p->photonMap->rgbdata != NULL)
        free(p->photonMap->rgbdata);
      free(p->photonMap);
    }
    free(p);
    p = q;
  }

  r = l_list; // Delete light source list
  while (r != NULL)
  {
    s = r->next;
    free(r);
    r = s;
  }

  t = t_list; // Delete texture Images
  while (t != NULL)
  {
    u = t->next;
    if (t->im->rgbdata != NULL)
      free(t->im->rgbdata);
    free(t->im);
    free(t);
    t = u;
  }
}
