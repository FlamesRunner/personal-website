/*
  CSC D18 - RayTracer code.

  Written Dec. 9 2010 - Jan 20, 2011 by F. J. Estrada
  Freely distributable for academic purposes only.

  Uses Tom F. El-Maraghi's code for computing inverse
  matrices. You will need to compile together with
  svdDynamic.c

  You need to understand the code provided in
  this file, the corresponding header file, and the
  utils.c and utils.h files. Do not worry about
  svdDynamic.c, we need it only to compute
  inverse matrices.

  You only need to modify or add code in sections
  clearly marked "TO DO" - remember to check what
  functionality is actually needed for the corresponding
  assignment!

  Last updated: Aug. 2017   - F.J.E.
*/

/*****************************************************************************
 * Several utility functions, and the skeleton of some functions were
 * written by F. Estrada. He is a professor at the University of Toronto (as of
 * 2022), and I have gratitude for his teaching and the foundational skills he
 * has given me and the rest of his students.
 * 
 * Much of the code was written by myself, Andrew Hong, with the help and
 * guidance of the CSC D18 teaching staff. I also wish to extend my gratitude
 * to Jackson for his help in figuring out a particularly nasty bug with the
 * plane intersection code, which turned out to be an one-line fix (I was missing
 * a negative multiplication in the plane intersection code, because when I went
 * through the math, I forgot that it would only work for a plane facing up "unit plane",
 * and not a plane facing down "also a unit plane".)
 * 
 * Andrew Hong, 2022
 ********************************************************************************/

#include "utils.h" // <-- This includes RayTracer.h

// A couple of global structures and data: An object list, a light list, and the
// maximum recursion depth
struct object3D *object_list;
struct pointLS *light_list;
struct textureNode *texture_list;
int MAX_DEPTH;
struct colourRGB background; // Background colour
int photons_cast = 0;
double photon_brightness = 0.01;

void buildScene(void)
{
#include "buildscene.c" // <-- Import the scene definition!
}

// temp
void printPt(struct point3D *pt)
{
  printf("PT: %f %f %f\n", pt->px, pt->py, pt->pz);
}

void rtShade(struct object3D *obj, struct point3D *p, struct point3D *n, struct ray3D *ray, int depth, double a, double b, struct colourRGB *col)
{
  // This function implements the shading model as described in lecture. It takes
  // - A pointer to the first object intersected by the ray (to get the colour properties)
  // - The coordinates of the intersection point (in world coordinates)
  // - The normal at the point
  // - The ray (needed to determine the reflection direction to use for the global component, as well as for
  //   the Phong specular component)
  // - The current racursion depth
  // - The (a,b) texture coordinates (meaningless unless texture is enabled)
  //
  // Returns:
  // - The colour for this ray (using the col pointer)
  //

  struct colourRGB tmp_col; // Accumulator for colour components
  double R, G, B;           // Colour for the object in R G and B
  double lambda;
  double alpha;
  struct object3D *obj_intn;

  // This will hold the colour as we process all the components of
  // the Phong illumination model
  tmp_col.R = 0;
  tmp_col.G = 0;
  tmp_col.B = 0;

  struct point3D normal_map;

  if (obj->texImg == NULL) // Not textured, use object colour
  {
    R = obj->col.R;
    G = obj->col.G;
    B = obj->col.B;
  }
  else
  {
    // Get object colour from the texture given the texture coordinates (a,b), and the texturing function
    // for the object. Note that we will use textures also for Photon Mapping.
    obj->textureMap(obj->texImg, a, b, &R, &G, &B);
  }

  if (obj->normalMap == NULL) // No normal map
  {
    normal_map = *n;
  }
  else
  {
    obj->textureMap(obj->normalMap, a, b, &normal_map.px, &normal_map.py, &normal_map.pz);
    normal_map.pw = 1;
  }

  if (obj->alphaMap == NULL)
  {
    alpha = obj->alb.ra;
  }
  else
  {
    alphaMap(obj->alphaMap, a, b, &alpha);
  }

  struct pointLS *ls_ptr = light_list;
  tmp_col.R += obj->alb.ra;
  tmp_col.G += obj->alb.ra;
  tmp_col.B += obj->alb.ra;

  while (ls_ptr != NULL)
  {
    struct ray3D temp_ray;
    struct object3D *temp_obj;
    double temp_lambda;
    struct point3D temp_normal, temp_intn;

    // get l_w - p_w
    temp_ray.p0 = *p;
    temp_ray.d = ls_ptr->p0;
    subVectors(p, &temp_ray.d);

    // Cast shadow ray
    double a, b;

    int areaLs = 0;
    int k_rays = 0;
    int rays_casted = 0;
    if (ls_ptr->areaLs != NULL)
    {
      struct point3D object_pt_rand;
      rays_casted = ls_ptr->lsSamples;
      for (int k = 0; k < ls_ptr->lsSamples; k++)
      {
        // Get random point on the object
        ls_ptr->areaLs->randomPoint(ls_ptr->areaLs, &object_pt_rand.px, &object_pt_rand.py, &object_pt_rand.pz);
        // printf("LS pt: %f %f %f\n", object_pt_rand.px, object_pt_rand.py, object_pt_rand.pz);

        // Create ray from int'n to object
        struct point3D ray_to_area_ls_d;
        ray_to_area_ls_d = object_pt_rand;
        subVectors(p, &ray_to_area_ls_d);
        normalize(&ray_to_area_ls_d);

        struct ray3D ray_to_area_ls;
        ray_to_area_ls.p0 = *p;
        ray_to_area_ls.d = ray_to_area_ls_d;

        // Fire ray
        findFirstHit(&ray_to_area_ls, &temp_lambda, obj, &temp_obj, &temp_intn, &temp_normal, &a, &b);

        // Check if there's a hit with the light source
        if (temp_obj == ls_ptr->areaLs)
        {
          k_rays++;
        }
      }
      areaLs = 1;
    }
    else
    {
      findFirstHit(&temp_ray, &temp_lambda, obj, &temp_obj, &temp_intn, &temp_normal, &a, &b);
    }

    if ((temp_lambda <= TOL || temp_lambda >= 1) || areaLs == 1)
    {
      // Soft shadows

      double percentage_of_rays = 1;
      if (areaLs == 1)
      {
        percentage_of_rays = (double)k_rays / (double)rays_casted;
      }

      // Diffuse
      struct point3D s = ls_ptr->p0;
      subVectors(p, &s);
      normalize(&s);

      double n_dot_s = dot(&normal_map, &s), max_n_s = 0.0;
      if (obj->frontAndBack == 1)
      {
        max_n_s = fabs(n_dot_s);
      }
      else
      {
        max_n_s = max(0.0, dot(&normal_map, &s));
      }

      tmp_col.R += R * max_n_s * obj->alb.rd * ls_ptr->col.R * percentage_of_rays;
      tmp_col.G += G * max_n_s * obj->alb.rd * ls_ptr->col.G * percentage_of_rays;
      tmp_col.B += B * max_n_s * obj->alb.rd * ls_ptr->col.B * percentage_of_rays;

      // Specular
      struct point3D cam_dir = ray->d;

      struct point3D m = normal_map;
      double s_dot_n = dot(&s, &normal_map) * 2.0;
      scaleVector(s_dot_n, &m);
      subVectors(&s, &m);

      double max_cm_dp = pow(max(0.0, dot(&cam_dir, &m)), obj->shinyness);
      tmp_col.R += max_cm_dp * obj->alb.rs * ls_ptr->col.R * percentage_of_rays;
      tmp_col.G += max_cm_dp * obj->alb.rs * ls_ptr->col.G * percentage_of_rays;
      tmp_col.B += max_cm_dp * obj->alb.rs * ls_ptr->col.B * percentage_of_rays;
    }
    ls_ptr = ls_ptr->next;
  }

  // Factor in alpha
  tmp_col.R *= obj->alpha;
  tmp_col.G *= obj->alpha;
  tmp_col.B *= obj->alpha;

  if (depth < MAX_DEPTH) // Global component
  {
    if (obj->alpha > 0) // Reflected
    {
      struct point3D mirror_dir = normal_map; // Figure out perfect mirror direction
      double dp_dn = 2.0 * dot(&ray->d, &normal_map);
      scaleVector(dp_dn, &mirror_dir);
      subVectors(&ray->d, &mirror_dir);
      normalize(&mirror_dir);

      struct ray3D new_ray = *ray;
      new_ray.d = mirror_dir;
      new_ray.p0 = *p;

      struct colourRGB reflected;
      rayTrace(&new_ray, depth + 1, &reflected, obj);

      tmp_col.R += reflected.R * obj->alb.rg;
      tmp_col.G += reflected.G * obj->alb.rg;
      tmp_col.B += reflected.B * obj->alb.rg;
    }

    if (obj->alpha < 1)
    { // Refraction
      // If the ray stack is empty, we're still outside of an object. So, this is a case of air to object.
      double c1, c2 = 0;
      if (ray->stack == NULL)
      {
        c1 = 1;
        c2 = obj->r_index;
        ray->stack = (ObjectList *)calloc(1, sizeof(ObjectList));
        ray->stack->object = obj;
        ray->stack->prev = NULL;
        ray->stack->next = NULL;
      }
      else
      {
        // There is a history of objects, so we're inside something
        c1 = ray->stack->object->r_index;

        // Check if we're entering or exiting an object
        // In other words, if the object on the stack is the one hit
        if (obj == ray->stack->object)
        {
          // Leaving an object, so move up to prev
          ray->stack = ray->stack->prev;

          if (ray->stack == NULL)
          { // Air
            c2 = 1;
          }
          else
          {
            c2 = ray->stack->object->r_index;
          }
        }
        else
        { // We're entering another object
          c2 = obj->r_index;
          // Move along the list
          ObjectList *temp = (ObjectList *)calloc(1, sizeof(ObjectList));
          temp->object = obj;
          temp->prev = ray->stack;
          ray->stack = temp;
        }
      }

      // Ratio
      double r = c1 / c2;
      struct point3D neg_norm = normal_map;
      scaleVector(-1, &neg_norm);
      double c = dot(&neg_norm, &ray->d);

      // Find the direction
      struct point3D rb = ray->d;
      scaleVector(r, &rb);

      double interior_component = r * c - sqrt(1 - r * r * (1 - c * c));
      struct point3D transmitted_dir = normal_map;
      scaleVector(interior_component, &transmitted_dir);
      addVectors(&rb, &transmitted_dir);
      normalize(&transmitted_dir);

      // Check for total internal refraction
      // Get current angle
      double ang = dot(&normal_map, &transmitted_dir) / (fabs(dot(&normal_map, &normal_map) * dot(&transmitted_dir, &transmitted_dir)));
      if (ang < 1)
      {
        // Create ray starting from the intersection point
        struct ray3D *transmitted_ray = (struct ray3D *)calloc(1, sizeof(struct ray3D));
        transmitted_ray->d = transmitted_dir;
        transmitted_ray->p0 = *p;
        transmitted_ray->stack = (ObjectList *)calloc(1, sizeof(ObjectList));
        transmitted_ray->stack = ray->stack;

        struct colourRGB transmitted;
        rayTrace(transmitted_ray, depth + 1, &transmitted, obj);

        double alpha_new = 1 - obj->alpha;
        tmp_col.R += transmitted.R * obj->alb.rg * alpha_new;
        tmp_col.G += transmitted.G * obj->alb.rg * alpha_new;
        tmp_col.B += transmitted.B * obj->alb.rg * alpha_new;

        free(transmitted_ray);
      }
    }
  }

  if (obj->photonMapped == 1) {
    struct colourRGB photonColour;
    obj->textureMap(obj->photonMap, a, b, &photonColour.R, &photonColour.G, &photonColour.B);
    tmp_col.R += photonColour.R;
    tmp_col.G += photonColour.G;
    tmp_col.B += photonColour.B;
  }

  col->R = R * max(0, min(1, tmp_col.R));
  col->G = G * max(0, min(1, tmp_col.G));
  col->B = B * max(0, min(1, tmp_col.B));
  return;
}

void findFirstHit(struct ray3D *ray, double *lambda, struct object3D *Os, struct object3D **obj, struct point3D *p, struct point3D *n, double *a, double *b)
{
  // Find the closest intersection between the ray and any objects in the scene.
  // Inputs:
  //   *ray    -  A pointer to the ray being traced
  //   *Os     -  'Object source' is a pointer toward the object from which the ray originates. It is used for reflected or refracted rays
  //              so that you can check for and ignore self-intersections as needed. It is NULL for rays originating at the center of
  //              projection
  // Outputs:
  //   *lambda -  A pointer toward a double variable 'lambda' used to return the lambda at the intersection point
  //   **obj   -  A pointer toward an (object3D *) variable so you can return a pointer to the object that has the closest intersection with
  //              this ray (this is required so you can do the shading)
  //   *p      -  A pointer to a 3D point structure so you can store the coordinates of the intersection point
  //   *n      -  A pointer to a 3D point structure so you can return the normal at the intersection point
  //   *a, *b  -  Pointers toward double variables so you can return the texture coordinates a,b at the intersection point

  struct object3D *ptr = object_list;
  *lambda = -1;
  *obj = NULL;

  while (ptr != NULL)
  {
    double currentLambda;
    struct point3D currentPt, currentNorm;
    if (ptr != Os)
    {
      ptr->intersect(ptr, ray, &currentLambda, &currentPt, &currentNorm, a, b);
      if ((*lambda < 0 || currentLambda < *lambda) && currentLambda < INFINITY)
      {
        *lambda = currentLambda;
        *p = currentPt;
        *n = currentNorm;
        *obj = ptr;
      }
    }
    ptr = ptr->next;
  }
}

void rayTrace(struct ray3D *ray, int depth, struct colourRGB *col, struct object3D *Os)
{
  // Trace one ray through the scene.
  //
  // Parameters:
  //   *ray   -  A pointer to the ray being traced
  //   depth  -  Current recursion depth for recursive raytracing
  //   *col   - Pointer to an RGB colour structure so you can return the object colour
  //            at the intersection point of this ray with the closest scene object.
  //   *Os    - 'Object source' is a pointer to the object from which the ray
  //            originates so you can discard self-intersections due to numerical
  //            errors. NULL for rays originating from the center of projection.

  double lambda;        // Lambda at intersection
  double a, b;          // Texture coordinates
  struct object3D *obj; // Pointer to object at intersection
  struct point3D p;     // Intersection point
  struct point3D n;     // Normal at intersection
  struct colourRGB I;   // Colour returned by shading function
  struct ray3D temp_ray = *ray;

  if (depth > MAX_DEPTH) // Max recursion depth reached. Return invalid colour.
  {
    col->R = -1;
    col->G = -1;
    col->B = -1;
    return;
  }

  findFirstHit(ray, &lambda, Os, &obj, &p, &n, &a, &b);
  if (lambda > 0 && lambda < INFINITY)
  {
    scaleVector(-1.0, &temp_ray.d);
    rtShade(obj, &p, &n, &temp_ray, depth, a, b, &I);
  }
  else
  {
    I.R = background.R; // background
    I.G = background.G;
    I.B = background.B;
  }

  *col = I;
}

void forwardTrace(struct ray3D *ray, struct object3D *originalLs, int depth)
{
  // Max recursion depth
  if (depth >= MAX_DEPTH)
  {
    return;
  }

  // Find first object hit
  double lambda, a, b;
  struct point3D p, n;
  struct object3D *temp_hit;
  findFirstHit(ray, &lambda, originalLs, &temp_hit, &p, &n, &a, &b);

  if (temp_hit != NULL)
  { // If we've hit something, then let's check if it's a diffuse surface
    if (temp_hit->photonMapped == 1 && depth > 0)
    {
        int pt_x = a * (temp_hit->photonMap->sx - 1);
        int pt_y = b * (temp_hit->photonMap->sy - 1);

        double *rgbdata = (double *)temp_hit->photonMap->rgbdata;

        rgbdata[(temp_hit->photonMap->sx * pt_y + pt_x) * 3] += ray->col.R * photon_brightness;
        rgbdata[(temp_hit->photonMap->sx * pt_y + pt_x) * 3 + 1] += ray->col.G * photon_brightness;
        rgbdata[(temp_hit->photonMap->sx * pt_y + pt_x) * 3 + 2] += ray->col.B * photon_brightness;
        return;
    }
    else
    {
      // Determine reflection/refraction rays
      struct point3D normal_mapped;
      if (temp_hit->normalMap != NULL)
      {
        temp_hit->textureMap(temp_hit->normalMap, a, b, &normal_mapped.px, &normal_mapped.py, &normal_mapped.pz);
      }
      else
      {
        normal_mapped = n;
      }

      // Reflection
      if (temp_hit->alpha > 0)
      {
        struct point3D mirror_dir = normal_mapped; // Figure out perfect mirror direction
        double dp_dn = 2.0 * dot(&ray->d, &normal_mapped);
        scaleVector(dp_dn, &mirror_dir);
        subVectors(&ray->d, &mirror_dir);
        normalize(&mirror_dir);

        struct ray3D new_ray;
        new_ray.col = ray->col;
        new_ray.col.R *= temp_hit->alpha;
        new_ray.col.G *= temp_hit->alpha;
        new_ray.col.B *= temp_hit->alpha;
        new_ray.p0 = p;
        new_ray.d = mirror_dir;
        new_ray.stack = ray->stack;

        forwardTrace(&new_ray, originalLs, depth+1);
      }

      // Refraction
      if (temp_hit->alpha < 1)
      {
        double c1, c2 = 1;
        int inside = 0;
        if (ray->stack == NULL)
        {
          c1 = 1;
          c2 = temp_hit->r_index;
          ray->stack = (ObjectList *)calloc(1, sizeof(ObjectList));
          ray->stack->object = temp_hit;
          ray->stack->prev = NULL;
          ray->stack->next = NULL;
        }
        else
        {
          // There is a history of objects, so we're inside something
          c1 = ray->stack->object->r_index;
          inside = 1;

          // Check if we're entering or exiting an object
          // In other words, if the object on the stack is the one hit
          if (temp_hit == ray->stack->object)
          {
            // Leaving an object, so move up to prev
            ray->stack = ray->stack->prev;

            if (ray->stack == NULL)
            { // Air
              c2 = 1;
            }
            else
            {
              c2 = ray->stack->object->r_index;
            }
          }
          else
          { // We're entering another object
            c2 = temp_hit->r_index;
            // Move along the list
            ObjectList *temp = (ObjectList *)calloc(1, sizeof(ObjectList));
            temp->object = temp_hit;
            temp->prev = ray->stack;
            ray->stack = temp;
          }
        }

        // Ratio
        double r = c1 / c2;
        if (c1 > c2) {
          return;
        }

        //printf("Depth: %d\n", depth);

        struct point3D neg_norm = normal_mapped;
        scaleVector(-1, &neg_norm);
        double c = dot(&neg_norm, &ray->d);

        // Find the direction
        struct point3D rb = ray->d;
        scaleVector(r, &rb);

        double interior_component = r * c - sqrt(1 - r * r * (1 - c * c));
        struct point3D transmitted_dir = normal_mapped;
        scaleVector(interior_component, &transmitted_dir);
        addVectors(&rb, &transmitted_dir);
        normalize(&transmitted_dir);

        // Check for total internal refraction
        // Get current angle
        double ang_temp = dot(&normal_mapped, &transmitted_dir) / (fabs(dot(&normal_mapped, &normal_mapped) * dot(&transmitted_dir, &transmitted_dir)));
        if (ang_temp > 1)
        {
          // Create ray starting from the intersection point
          struct ray3D *transmitted_ray = (struct ray3D *)calloc(1, sizeof(struct ray3D));
          transmitted_ray->d = transmitted_dir;
          transmitted_ray->p0 = p;
          //transmitted_ray->stack = (ObjectList *)calloc(1, sizeof(ObjectList));
          transmitted_ray->stack = ray->stack;

          struct colourRGB transmitted;
          // Propagate ray with modulated colour

          double ang = acos(ang_temp);
          double r0 = pow((c1-c2)/(c1+c2), 2);
          double r_theta = pow(r0+((1-r0)*(1-cos(ang))), 5);
          double rt = 1.0 - r_theta;
          transmitted_ray->col.R = ray->col.R * rt;
          transmitted_ray->col.G = ray->col.G * rt;
          transmitted_ray->col.B = ray->col.B * rt;
          printf("%f %f %f dir\n", transmitted_dir.px, transmitted_dir.py, transmitted_dir.pz);
          forwardTrace(transmitted_ray, originalLs, depth + 1);
          free(transmitted_ray);
        }
      }
    }
  }
}

int main(int argc, char *argv[])
{
  // Main function for the raytracer. Parses input parameters,
  // sets up the initial blank image, and calls the functions
  // that set up the scene and do the raytracing.
  struct image *im;       // Will hold the raytraced image
  int sx;                 // Size of the raytraced image
  int antialiasing;       // Flag to determine whether antialiaing is enabled or disabled
  char output_name[1024]; // Name of the output file for the raytraced .ppm image
  struct point3D e;       // Camera view parameters 'e', 'g', and 'up'
  struct point3D g;
  struct point3D up;
  double du, dv;        // Increase along u and v directions for pixel coordinates
  struct point3D pc, d; // Point structures to keep the coordinates of a pixel and
                        // the direction or a ray
  struct ray3D ray;     // Structure to keep the ray from e to a pixel
  struct colourRGB col; // Return colour for raytraced pixels
  int i, j;             // Counters for pixel coordinates
  unsigned char *rgbIm;
  struct view *cam;          // Camera and view for this scene
  int number_of_samples = 4; // Number of samples to take per pixel for the purpose of antialiasing
  int max_photons = 70000;

  if (argc < 5)
  {
    fprintf(stderr, "RayTracer: Can not parse input parameters\n");
    fprintf(stderr, "USAGE: RayTracer size rec_depth antialias output_name sample_size\n");
    fprintf(stderr, "   size = Image size (both along x and y)\n");
    fprintf(stderr, "   rec_depth = Recursion depth\n");
    fprintf(stderr, "   antialias = A single digit, 0 disables antialiasing. Anything else enables antialiasing\n");
    fprintf(stderr, "   output_name = Name of the output file, e.g. MyRender.ppm\n");
    fprintf(stderr, "   sample_size = Number of samples to take for each pixel (antialiasing). Optional; defaults to 4.\n");
    exit(0);
  }
  sx = atoi(argv[1]);
  MAX_DEPTH = atoi(argv[2]);
  if (atoi(argv[3]) == 0)
    antialiasing = 0;
  else
    antialiasing = 1;
  strcpy(&output_name[0], argv[4]);

  if (argc == 6)
  {
    number_of_samples = atoi(argv[5]);
  }

  fprintf(stderr, "Rendering image at %d x %d\n", sx, sx);
  fprintf(stderr, "Recursion depth = %d\n", MAX_DEPTH);
  if (!antialiasing)
    fprintf(stderr, "Antialising is off\n");
  else
  {
    fprintf(stderr, "Antialising is on\n");
    fprintf(stderr, "Using %d samples\n", number_of_samples);
  }
  fprintf(stderr, "Output file name: %s\n", output_name);

  object_list = NULL;
  light_list = NULL;
  texture_list = NULL;

  // Allocate memory for the new image
  im = newImage(sx, sx);
  if (!im)
  {
    fprintf(stderr, "Unable to allocate memory for raytraced image\n");
    exit(0);
  }
  else
    rgbIm = (unsigned char *)im->rgbdata;

  buildScene(); // Create a scene. This defines all the
                // objects in the world of the raytracer

  // Mind the homogeneous coordinate w of all vectors below. DO NOT
  // forget to set it to 1, or you'll get junk out of the
  // geometric transformations later on.

  // Camera center is at (0,0,-1)
  e.px = 0;
  e.py = 0;
  e.pz = -1;
  e.pw = 1;

  // To define the gaze vector, we choose a point 'pc' in the scene that
  // the camera is looking at, and do the vector subtraction pc-e.
  // Here we set up the camera to be looking at the origin.
  g.px = 0 - e.px;
  g.py = 0 - e.py;
  g.pz = 0 - e.pz;
  g.pw = 1;
  // In this case, the camera is looking along the world Z axis, so
  // vector w should end up being [0, 0, -1]

  // Define the 'up' vector to be the Y axis
  up.px = 0;
  up.py = 1;
  up.pz = 0;
  up.pw = 1;

  // Set up view with given the above vectors, a 4x4 window,
  // and a focal length of -1 (why? where is the image plane?)
  // Note that the top-left corner of the window is at (-2, 2)
  // in camera coordinates.
  cam = setupView(&e, &g, &up, -1, -2, 2, 4);

  if (cam == NULL)
  {
    fprintf(stderr, "Unable to set up the view and camera parameters. Our of memory!\n");
    cleanup(object_list, light_list, texture_list);
    deleteImage(im);
    exit(0);
  }

  // Set up background colour here
  background.R = 0;
  background.G = 0;
  background.B = 0;

  // Do the raytracing
  du = cam->wsize / (sx - 1);  // du and dv. In the notes in terms of wl and wr, wt and wb,
  dv = -cam->wsize / (sx - 1); // here we use wl, wt, and wsize. du=dv since the image is
                               // and dv is negative since y increases downward in pixel
                               // coordinates and upward in camera coordinates.

  fprintf(stderr, "View parameters:\n");
  fprintf(stderr, "Left=%f, Top=%f, Width=%f, f=%f\n", cam->wl, cam->wt, cam->wsize, cam->f);
  fprintf(stderr, "Camera to world conversion matrix (make sure it makes sense!):\n");
  printmatrix(cam->C2W);
  fprintf(stderr, "World to camera conversion matrix:\n");
  printmatrix(cam->W2C);
  fprintf(stderr, "\n");
  fprintf(stderr, "Starting forward rendering pass for photon map...\n");

  // Count light sources
  struct pointLS *ls_ptr = light_list;
  int ls_count = 0;
  while (ls_ptr != NULL)
  {
    if (ls_ptr->areaLs != NULL)
      ls_count++;
    ls_ptr = ls_ptr->next;
  }
  photons_cast = max_photons;

  //#pragma omp parallel for schedule(dynamic, 32)
  for (int photon = 0; photon < max_photons; photon++)
  {
    // Pick some random light source
    int source = floor(((double)rand() / (double)RAND_MAX) * (double)ls_count);
    struct pointLS *current_ptr = light_list;
    int l = 0;
    while (l < source)
    {
      if (current_ptr->areaLs != NULL)
        l++;
      current_ptr = current_ptr->next;
    }

    struct object3D *ls_obj = current_ptr->areaLs;

    // Create ray
    struct ray3D new_ray;
    ls_obj->randomPoint(ls_obj, &new_ray.p0.px, &new_ray.p0.py, &new_ray.p0.pz);

    // Pick random direction
    new_ray.d.px = (2.0 * (double)rand() / (double)RAND_MAX) - 1.0;
    new_ray.d.py = (2.0 * (double)rand() / (double)RAND_MAX) - 1.0;
    new_ray.d.pz = (2.0 * (double)rand() / (double)RAND_MAX) - 1.0;
    new_ray.stack = NULL;

    // Set colour
    new_ray.col = current_ptr->col;

    // Trace it
    forwardTrace(&new_ray, ls_obj, 0);

    // Clean up stack
    ObjectList *stack_ptr = new_ray.stack;
    while (stack_ptr != NULL) {
      ObjectList *next = stack_ptr->prev;
      free(stack_ptr);
      stack_ptr = next;
    }
  }

  fprintf(stderr, "Finished forward rendering pass. Starting backward tracing...\n");
  fprintf(stderr, "Rendering row: ");
#pragma omp parallel for schedule(dynamic, 32) collapse(2)
  for (j = 0; j < sx; j++) // For each of the pixels in the image
  {
    for (i = 0; i < sx; i++)
    {
      struct colourRGB col_samples[number_of_samples];

      if (antialiasing == 0)
      {
        number_of_samples = 1;
      }

#pragma omp parallel for schedule(dynamic, 1)
      for (int sample = 0; sample < number_of_samples; sample++)
      {
        double ci = i;
        double cj = j;

        if (antialiasing == 1)
        {
          ci += (double)rand() / (double)RAND_MAX;
          cj += (double)rand() / (double)RAND_MAX;
        }

        struct point3D current_pixel;
        current_pixel.px = cam->wl + ci * du;
        current_pixel.py = cam->wt + cj * dv;
        current_pixel.pz = cam->f;
        current_pixel.pw = 1;

        // Convert to world coordinates
        matVecMult(cam->C2W, &current_pixel);

        // Set up ray
        struct ray3D new_ray;
        new_ray.p0 = current_pixel;
        new_ray.d = current_pixel;
        new_ray.stack = NULL;
        subVectors(&cam->e, &new_ray.d);

        // Normalize
        normalize(&new_ray.d);

        // Ray trace
        rayTrace(&new_ray, 1, &col_samples[sample], NULL);

        while (new_ray.stack != NULL)
        {
          ObjectList *tmp = new_ray.stack;
          new_ray.stack = new_ray.stack->prev;
          free(tmp);
        }
      }

      // Need to average out the colours
      double col_count = (antialiasing == 1) ? number_of_samples : 1;
      double tr = 0, tg = 0, tb = 0;
      for (int col_it = 0; col_it < col_count; col_it++)
      {
        tr += col_samples[col_it].R;
        tg += col_samples[col_it].G;
        tb += col_samples[col_it].B;
      }

      tr /= col_count;
      tg /= col_count;
      tb /= col_count;

      // Save to image (tested)
      rgbIm[(sx * j + i) * 3] = (unsigned int)round(tr * 255);
      rgbIm[(sx * j + i) * 3 + 1] = (unsigned int)round(tg * 255);
      rgbIm[(sx * j + i) * 3 + 2] = (unsigned int)round(tb * 255);

      if (i == 0)
        fprintf(stderr, "%d/%d, ", j, sx);
    } // end for i
  }   // end for j

  fprintf(stderr, "\nDone!\n");

  // Output rendered image
  imageOutput(im, output_name);

  // Exit section. Clean up and return.
  cleanup(object_list, light_list, texture_list); // Object, light, and texture lists
  deleteImage(im);                                // Rendered image
  free(cam);                                      // camera view
  exit(0);
}
