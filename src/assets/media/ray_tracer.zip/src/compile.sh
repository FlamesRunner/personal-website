#!/bin/sh
g++ -O3 -fopenmp -g svdDynamic.c RayTracer.c utils.c -lm -o RayTracer
